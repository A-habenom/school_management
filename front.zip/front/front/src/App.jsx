import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from './contexts/AuthContext';

// Layout
import Layout from './components/layout/Layout';
import ErrorBoundary from './components/common/ErrorBoundary';

// Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Dashboard from './pages/dashboard/Dashboard';
import Users from './pages/users/Users';
import AcademicYears from './pages/academic/AcademicYears';
import Subjects from './pages/academic/Subjects';
import Classes from './pages/classes/Classes';
import Timetable from './pages/timetable/Timetable';
import Reports from './pages/reports/Reports';
import Settings from './pages/settings/Settings';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <Toaster 
              position="top-right" 
              toastOptions={{
                duration: 4000,
                style: {
                  background: '#363636',
                  color: '#fff',
                },
                success: {
                  duration: 3000,
                  iconTheme: {
                    primary: '#10b981',
                    secondary: '#fff',
                  },
                },
                error: {
                  duration: 4000,
                  iconTheme: {
                    primary: '#ef4444',
                    secondary: '#fff',
                  },
                },
              }}
            />
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              
              {/* Protected Routes */}
              <Route element={<Layout />}>
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                
                <Route path="/dashboard" element={
                  <ErrorBoundary>
                    <Dashboard />
                  </ErrorBoundary>
                } />
                
                <Route path="/users" element={
                  <ErrorBoundary>
                    <Users />
                  </ErrorBoundary>
                } />
                
                <Route path="/academic/years" element={
                  <ErrorBoundary>
                    <AcademicYears />
                  </ErrorBoundary>
                } />
                
                <Route path="/academic/subjects" element={
                  <ErrorBoundary>
                    <Subjects />
                  </ErrorBoundary>
                } />
                
                <Route path="/classes" element={
                  <ErrorBoundary>
                    <Classes />
                  </ErrorBoundary>
                } />
                
                <Route path="/timetable" element={
                  <ErrorBoundary>
                    <Timetable />
                  </ErrorBoundary>
                } />
                
                <Route path="/reports" element={
                  <ErrorBoundary>
                    <Reports />
                  </ErrorBoundary>
                } />
                
                <Route path="/settings" element={
                  <ErrorBoundary>
                    <Settings />
                  </ErrorBoundary>
                } />
              </Route>
              
              {/* 404 Route */}
              <Route path="*" element={
                <div className="min-h-screen flex items-center justify-center">
                  <div className="text-center">
                    <h1 className="text-4xl font-bold text-gray-900">404</h1>
                    <p className="mt-2 text-gray-600">Page not found</p>
                    <a 
                      href="/dashboard" 
                      className="mt-4 inline-block text-blue-600 hover:text-blue-800"
                    >
                      Go to Dashboard
                    </a>
                  </div>
                </div>
              } />
            </Routes>
          </div>
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;