import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { X, UserPlus, GraduationCap, Calendar } from 'lucide-react';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';
import Button from '../common/Button';

const EnrollStudentModal = ({ isOpen, onClose, selectedClass = null }) => {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    student_id: '',
    class_id: selectedClass?.id || '',
    academic_year_id: '',
    enrollment_date: new Date().toISOString().split('T')[0],
    roll_number: '',
  });

  // Fetch students
  const { data: studentsData } = useQuery({
    queryKey: ['students'],
    queryFn: async () => {
      // Placeholder - fetch students from users with user_type = 'student'
      return { data: [] };
    },
  });

  // Fetch academic years
  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  // Fetch class students
  const { data: classStudentsData } = useQuery({
    queryKey: ['class-students', selectedClass?.id],
    queryFn: () => classesService.getClassStudents({ 
      class_id: selectedClass?.id 
    }),
    enabled: !!selectedClass?.id,
  });

  const enrollMutation = useMutation({
    mutationFn: classesService.enrollStudent,
    onSuccess: () => {
      toast.success('Student enrolled successfully');
      queryClient.invalidateQueries(['class-students']);
      setFormData({
        student_id: '',
        class_id: selectedClass?.id || '',
        academic_year_id: '',
        enrollment_date: new Date().toISOString().split('T')[0],
        roll_number: '',
      });
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to enroll student');
    },
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.student_id || !formData.class_id || !formData.academic_year_id) {
      toast.error('Please fill in all required fields');
      return;
    }

    enrollMutation.mutate(formData);
  };

  if (!isOpen) return null;

  const students = studentsData?.data || [];
  const academicYears = academicYearsData?.data || [];
  const classStudents = classStudentsData?.data || [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            Enroll Student
            {selectedClass && (
              <span className="text-gray-600 ml-2">
                • {selectedClass.name} {selectedClass.section && `(${selectedClass.section})`}
              </span>
            )}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column - Enrollment Form */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Enroll New Student</h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  {!selectedClass && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Select Class *
                      </label>
                      <select
                        name="class_id"
                        value={formData.class_id}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="">Select Class</option>
                        {/* Classes would be fetched here */}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Student *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <UserPlus className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        name="student_id"
                        value={formData.student_id}
                        onChange={handleChange}
                        className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="">Select Student</option>
                        {students.map(student => (
                          <option key={student.id} value={student.id}>
                            {student.first_name} {student.last_name} ({student.email})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Academic Year *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        name="academic_year_id"
                        value={formData.academic_year_id}
                        onChange={handleChange}
                        className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="">Select Academic Year</option>
                        {academicYears.map(year => (
                          <option key={year.id} value={year.id}>
                            {year.name} {year.is_current && '(Current)'}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Enrollment Date
                      </label>
                      <input
                        type="date"
                        name="enrollment_date"
                        value={formData.enrollment_date}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Roll Number
                      </label>
                      <input
                        type="text"
                        name="roll_number"
                        value={formData.roll_number}
                        onChange={handleChange}
                        placeholder="Auto-generate if blank"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={enrollMutation.isLoading}
                    className="w-full"
                  >
                    {enrollMutation.isLoading ? 'Enrolling...' : 'Enroll Student'}
                  </Button>
                </form>
              </div>

              {/* Right Column - Current Students */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Current Students
                  {classStudents.length > 0 && (
                    <span className="text-gray-600 text-sm font-normal ml-2">
                      ({classStudents.length} students)
                    </span>
                  )}
                </h3>

                {classStudents.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                    <GraduationCap className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No students enrolled yet</p>
                    <p className="text-sm text-gray-500 mt-1">
                      Enroll students using the form
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {classStudents.map((student) => (
                      <div key={student.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                              <span className="text-blue-600 font-medium">
                                {student.first_name?.[0]}{student.last_name?.[0]}
                              </span>
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-900">
                                {student.first_name} {student.last_name}
                              </h4>
                              <p className="text-sm text-gray-600">
                                Roll: {student.roll_number} • {student.email}
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              if (confirm(`Remove ${student.first_name} from this class?`)) {
                                toast.error('Remove functionality coming soon');
                              }
                            }}
                            className="text-red-600 hover:text-red-900 p-1"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50">
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-600">
              {selectedClass && (
                <span>
                  Class Capacity: {selectedClass.capacity || 30} students
                </span>
              )}
            </div>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={onClose}
                disabled={enrollMutation.isLoading}
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnrollStudentModal;