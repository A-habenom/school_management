import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { X, BookOpen, User, GraduationCap } from 'lucide-react';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';
import Button from '../common/Button';

const AllocateSubjectModal = ({ isOpen, onClose, selectedClass = null }) => {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    class_id: selectedClass?.id || '',
    subject_id: '',
    teacher_id: '',
    academic_year_id: '',
  });

  // Fetch subjects
  const { data: subjectsData } = useQuery({
    queryKey: ['subjects'],
    queryFn: academicService.getSubjects,
  });

  // Fetch teachers
  const { data: teachersData } = useQuery({
    queryKey: ['teachers'],
    queryFn: async () => {
      // Placeholder - you need to implement this
      return { data: [] };
    },
  });

  // Fetch academic years
  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  // Fetch class subjects
  const { data: classSubjectsData } = useQuery({
    queryKey: ['class-subjects', selectedClass?.id],
    queryFn: () => classesService.getClassSubjects({ 
      class_id: selectedClass?.id 
    }),
    enabled: !!selectedClass?.id,
  });

  const allocateMutation = useMutation({
    mutationFn: classesService.getAllocateSubject,
    onSuccess: () => {
      toast.success('Subject allocated successfully');
      queryClient.invalidateQueries(['class-subjects']);
      setFormData({
        class_id: selectedClass?.id || '',
        subject_id: '',
        teacher_id: '',
        academic_year_id: '',
      });
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to allocate subject');
    },
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.class_id || !formData.subject_id || !formData.teacher_id || !formData.academic_year_id) {
      toast.error('Please fill in all fields');
      return;
    }

    allocateMutation.mutate(formData);
  };

  if (!isOpen) return null;

  const subjects = subjectsData?.data || [];
  const teachers = teachersData?.data || [];
  const academicYears = academicYearsData?.data || [];
  const classSubjects = classSubjectsData?.data || [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            Allocate Subjects to Class
            {selectedClass && (
              <span className="text-gray-600 ml-2">
                • {selectedClass.name} {selectedClass.section && `(${selectedClass.section})`}
              </span>
            )}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column - Allocation Form */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Allocate New Subject</h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  {!selectedClass && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Select Class *
                      </label>
                      <select
                        name="class_id"
                        value={formData.class_id}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="">Select Class</option>
                        {/* Classes would be fetched here */}
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <BookOpen className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        name="subject_id"
                        value={formData.subject_id}
                        onChange={handleChange}
                        className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="">Select Subject</option>
                        {subjects.map(subject => (
                          <option key={subject.id} value={subject.id}>
                            {subject.name} ({subject.code})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Teacher *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        name="teacher_id"
                        value={formData.teacher_id}
                        onChange={handleChange}
                        className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        required
                      >
                        <option value="">Select Teacher</option>
                        {teachers.map(teacher => (
                          <option key={teacher.id} value={teacher.id}>
                            {teacher.first_name} {teacher.last_name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Academic Year *
                    </label>
                    <select
                      name="academic_year_id"
                      value={formData.academic_year_id}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    >
                      <option value="">Select Academic Year</option>
                      {academicYears.map(year => (
                        <option key={year.id} value={year.id}>
                          {year.name} {year.is_current && '(Current)'}
                        </option>
                      ))}
                    </select>
                  </div>

                  <Button
                    type="submit"
                    disabled={allocateMutation.isLoading}
                    className="w-full"
                  >
                    {allocateMutation.isLoading ? 'Allocating...' : 'Allocate Subject'}
                  </Button>
                </form>
              </div>

              {/* Right Column - Current Allocations */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Current Subject Allocations
                  {classSubjects.length > 0 && (
                    <span className="text-gray-600 text-sm font-normal ml-2">
                      ({classSubjects.length} subjects)
                    </span>
                  )}
                </h3>

                {classSubjects.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                    <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No subjects allocated yet</p>
                    <p className="text-sm text-gray-500 mt-1">
                      Allocate subjects using the form
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {classSubjects.map((allocation) => (
                      <div key={allocation.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {allocation.subject_name}
                            </h4>
                            <p className="text-sm text-gray-600">
                              Code: {allocation.subject_code}
                            </p>
                            <div className="mt-2 flex items-center text-sm">
                              <User className="h-4 w-4 text-gray-400 mr-1" />
                              <span className="text-gray-700">
                                {allocation.teacher_first_name} {allocation.teacher_last_name}
                              </span>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              if (confirm(`Remove ${allocation.subject_name} from this class?`)) {
                                toast.error('Remove functionality coming soon');
                              }
                            }}
                            className="text-red-600 hover:text-red-900 p-1"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50">
          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={allocateMutation.isLoading}
            >
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllocateSubjectModal;