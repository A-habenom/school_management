import { useForm } from 'react-hook-form';
import { toast } from 'react-hot-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { X } from 'lucide-react';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';
import Button from '../common/Button';

const ClassForm = ({ isOpen, onClose, classData = null }) => {
  const queryClient = useQueryClient();
  
  // Fetch academic years for dropdown
  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  // Fetch teachers for dropdown
  const { data: teachersData } = useQuery({
    queryKey: ['teachers'],
    queryFn: async () => {
      // You'll need to create this endpoint or filter from users
      // This is a placeholder - adjust based on your API
      return { data: [] };
    },
  });

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: classData || {
      name: '',
      academic_year_id: '',
      section: '',
      capacity: 30,
      class_teacher_id: '',
    }
  });

  const createMutation = useMutation({
    mutationFn: classesService.createClass,
    onSuccess: () => {
      toast.success('Class created successfully');
      queryClient.invalidateQueries(['classes']);
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to create class');
    },
  });

  const onSubmit = (data) => {
    // Convert capacity to number
    data.capacity = parseInt(data.capacity);
    
    if (classData) {
      // TODO: Update class mutation when your API supports it
      toast.error('Update functionality coming soon');
    } else {
      createMutation.mutate(data);
    }
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  if (!isOpen) return null;

  const academicYears = academicYearsData?.data || [];
  const teachers = teachersData?.data || [];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-md">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            {classData ? 'Edit Class' : 'Create New Class'}
          </h2>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Class Name *
              </label>
              <input
                type="text"
                {...register('name', { required: 'Class name is required' })}
                placeholder="e.g., Class 10, Grade 12"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Section
              </label>
              <input
                type="text"
                {...register('section')}
                placeholder="e.g., A, B, Science, Commerce"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Academic Year *
              </label>
              <select
                {...register('academic_year_id', { required: 'Academic year is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Select Academic Year</option>
                {academicYears.map(year => (
                  <option key={year.id} value={year.id}>
                    {year.name} {year.is_current && '(Current)'}
                  </option>
                ))}
              </select>
              {errors.academic_year_id && (
                <p className="mt-1 text-sm text-red-600">{errors.academic_year_id.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Capacity
              </label>
              <input
                type="number"
                {...register('capacity', { 
                  min: { value: 1, message: 'Capacity must be at least 1' },
                  max: { value: 100, message: 'Capacity cannot exceed 100' }
                })}
                min="1"
                max="100"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {errors.capacity && (
                <p className="mt-1 text-sm text-red-600">{errors.capacity.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Class Teacher
              </label>
              <select
                {...register('class_teacher_id')}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Select Class Teacher (Optional)</option>
                {teachers.map(teacher => (
                  <option key={teacher.id} value={teacher.id}>
                    {teacher.first_name} {teacher.last_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> Class teacher can be assigned later. 
                This teacher will have special permissions for this class.
              </p>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={createMutation.isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isLoading}
            >
              {createMutation.isLoading 
                ? 'Saving...' 
                : classData 
                  ? 'Update Class' 
                  : 'Create Class'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ClassForm;