import { useForm } from 'react-hook-form';
import { toast } from 'react-hot-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { X } from 'lucide-react';
import { academicService } from '../../services/academic.service';
import Button from '../common/Button';

const AcademicYearForm = ({ isOpen, onClose, year = null }) => {
  const queryClient = useQueryClient();
  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: year || {
      name: '',
      start_date: '',
      end_date: '',
      is_current: false
    }
  });

  const createMutation = useMutation({
    mutationFn: academicService.createAcademicYear,
    onSuccess: () => {
      toast.success('Academic year created successfully');
      queryClient.invalidateQueries(['academic-years']);
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to create academic year');
    },
  });

  const onSubmit = (data) => {
    if (new Date(data.end_date) <= new Date(data.start_date)) {
      toast.error('End date must be after start date');
      return;
    }

    createMutation.mutate(data);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-md">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            {year ? 'Edit Academic Year' : 'Add Academic Year'}
          </h2>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Year Name *
              </label>
              <input
                type="text"
                {...register('name', { required: 'Year name is required' })}
                placeholder="e.g., 2024-2025"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date *
              </label>
              <input
                type="date"
                {...register('start_date', { required: 'Start date is required' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {errors.start_date && (
                <p className="mt-1 text-sm text-red-600">{errors.start_date.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date *
              </label>
              <input
                type="date"
                {...register('end_date', { 
                  required: 'End date is required',
                  validate: (value, formValues) => {
                    if (new Date(value) <= new Date(formValues.start_date)) {
                      return 'End date must be after start date';
                    }
                    return true;
                  }
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {errors.end_date && (
                <p className="mt-1 text-sm text-red-600">{errors.end_date.message}</p>
              )}
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="is_current"
                {...register('is_current')}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="is_current" className="ml-2 block text-sm text-gray-900">
                Set as current academic year
              </label>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-sm text-yellow-800">
                <strong>Note:</strong> Setting this as current will automatically deactivate any other current academic year.
              </p>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={createMutation.isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isLoading}
            >
              {createMutation.isLoading ? 'Saving...' : year ? 'Update Year' : 'Create Year'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AcademicYearForm;