import { useForm } from 'react-hook-form';
import { toast } from 'react-hot-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { X, Clock, School, BookOpen, User, MapPin } from 'lucide-react';
import { timetableService } from '../../services/timetable.service';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';
import Button from '../common/Button';

const TimetableForm = ({ isOpen, onClose, entry = null }) => {
  const queryClient = useQueryClient();
  
  // Fetch classes for dropdown
  const { data: classesData } = useQuery({
    queryKey: ['classes'],
    queryFn: classesService.getClasses,
  });

  // Fetch subjects for dropdown
  const { data: subjectsData } = useQuery({
    queryKey: ['subjects'],
    queryFn: academicService.getSubjects,
  });

  // Fetch teachers for dropdown
  const { data: teachersData } = useQuery({
    queryKey: ['teachers'],
    queryFn: async () => {
      // Placeholder - you need to implement this
      return { data: [] };
    },
  });

  // Fetch academic years for dropdown
  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm({
    defaultValues: entry || {
      class_id: '',
      subject_id: '',
      teacher_id: '',
      day_of_week: 'Monday',
      start_time: '08:00',
      end_time: '09:00',
      room_number: '',
      academic_year_id: '',
    }
  });

  const createMutation = useMutation({
    mutationFn: timetableService.createTimetableEntry,
    onSuccess: () => {
      toast.success('Timetable entry created successfully');
      queryClient.invalidateQueries(['timetable']);
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to create timetable entry');
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => timetableService.updateTimetableEntry(entry.id, data),
    onSuccess: () => {
      toast.success('Timetable entry updated successfully');
      queryClient.invalidateQueries(['timetable']);
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update timetable entry');
    },
  });

  const onSubmit = (data) => {
    if (data.end_time <= data.start_time) {
      toast.error('End time must be after start time');
      return;
    }

    if (entry) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  if (!isOpen) return null;

  const classes = classesData?.data || [];
  const subjects = subjectsData?.data || [];
  const teachers = teachersData?.data || [];
  const academicYears = academicYearsData?.data || [];
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  
  const selectedClassId = watch('class_id');
  const selectedClass = classes.find(c => c.id === parseInt(selectedClassId));
  const isLoading = createMutation.isLoading || updateMutation.isLoading;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-md">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            {entry ? 'Edit Timetable Entry' : 'Add Timetable Entry'}
          </h2>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Class *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <School className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  {...register('class_id', { required: 'Class is required' })}
                  className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select Class</option>
                  {classes.map(cls => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name} {cls.section && `(${cls.section})`}
                    </option>
                  ))}
                </select>
              </div>
              {errors.class_id && (
                <p className="mt-1 text-sm text-red-600">{errors.class_id.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subject *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <BookOpen className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  {...register('subject_id', { required: 'Subject is required' })}
                  className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select Subject</option>
                  {subjects.map(subject => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name} ({subject.code})
                    </option>
                  ))}
                </select>
              </div>
              {errors.subject_id && (
                <p className="mt-1 text-sm text-red-600">{errors.subject_id.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Teacher *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  {...register('teacher_id', { required: 'Teacher is required' })}
                  className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select Teacher</option>
                  {teachers.map(teacher => (
                    <option key={teacher.id} value={teacher.id}>
                      {teacher.first_name} {teacher.last_name}
                    </option>
                  ))}
                </select>
              </div>
              {errors.teacher_id && (
                <p className="mt-1 text-sm text-red-600">{errors.teacher_id.message}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Day of Week *
                </label>
                <select
                  {...register('day_of_week', { required: 'Day is required' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  {daysOfWeek.map(day => (
                    <option key={day} value={day}>{day}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Academic Year *
                </label>
                <select
                  {...register('academic_year_id', { required: 'Academic year is required' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select Year</option>
                  {academicYears.map(year => (
                    <option key={year.id} value={year.id}>
                      {year.name} {year.is_current && '(Current)'}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Start Time *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Clock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="time"
                    {...register('start_time', { required: 'Start time is required' })}
                    className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  End Time *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Clock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="time"
                    {...register('end_time', { 
                      required: 'End time is required',
                      validate: (value, formValues) => {
                        if (value <= formValues.start_time) {
                          return 'End time must be after start time';
                        }
                        return true;
                      }
                    })}
                    className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Room Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MapPin className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  {...register('room_number')}
                  placeholder="e.g., Room 101, Lab 2"
                  className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            {selectedClass && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Selected Class:</strong> {selectedClass.name} {selectedClass.section && `(${selectedClass.section})`}
                </p>
                <p className="text-sm text-blue-800 mt-1">
                  <strong>Capacity:</strong> {selectedClass.capacity || 30} students
                </p>
                {selectedClass.teacher_first_name && (
                  <p className="text-sm text-blue-800 mt-1">
                    <strong>Class Teacher:</strong> {selectedClass.teacher_first_name} {selectedClass.teacher_last_name}
                  </p>
                )}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
            >
              {isLoading 
                ? 'Saving...' 
                : entry 
                  ? 'Update Entry' 
                  : 'Create Entry'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TimetableForm;