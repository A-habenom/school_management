import api from './api';

export const academicService = {
  // Academic Years
  getAcademicYears: () => api.get('/academic/years'),
  createAcademicYear: (data) => api.post('/academic/years', data),
  setCurrentAcademicYear: (id) => api.put(`/academic/years/${id}/set-current`),

  // Subjects
  getSubjects: () => api.get('/academic/subjects'),
  createSubject: (data) => api.post('/academic/subjects', data),
  updateSubject: (id, data) => api.put(`/academic/subjects/${id}`, data),
  deleteSubject: (id) => api.delete(`/academic/subjects/${id}`),
};