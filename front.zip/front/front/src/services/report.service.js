import api from './api';

export const reportService = {
  // Generate class report
  generateClassReport: (params) => api.get('/reports/class-report', { params }),

  // Get generated reports
  getReports: (params = {}) => {
    const queryParams = new URLSearchParams(params).toString();
    return api.get(`/reports/generated?${queryParams}`);
  },

  // Download report
  downloadReport: (id, format = 'pdf') => 
    api.get(`/reports/download/${id}?format=${format}`, {
      responseType: 'blob'
    }),

  // Generate custom report
  generateCustomReport: (data) => api.post('/reports/generate', data),

  // Get report templates
  getReportTemplates: () => api.get('/reports/templates'),

  // Schedule report generation
  scheduleReport: (data) => api.post('/reports/schedule', data),
};