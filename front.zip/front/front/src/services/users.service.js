import api from './api';

export const usersService = {
  // Get all users with pagination and filters
  getUsers: (params = {}) => {
    const queryParams = new URLSearchParams(params).toString();
    return api.get(`/users?${queryParams}`);
  },

  // Get single user by ID
  getUserById: (id) => api.get(`/users/${id}`),

  // Create new user
  createUser: (userData) => api.post('/users', userData),

  // Update user
  updateUser: (id, userData) => api.put(`/users/${id}`, userData),

  // Deactivate user
  deactivateUser: (id) => api.put(`/users/${id}/deactivate`),

  // Activate user
  activateUser: (id) => api.put(`/users/${id}/activate`),
};