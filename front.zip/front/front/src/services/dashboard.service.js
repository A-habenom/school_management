import api from './api';

export const dashboardService = {
  // Get system statistics (from your first export)
  getStats: () => api.get('/reports/stats'),

  // Get recent audit logs (from your first export)
  getRecentActivities: (limit = 10) => 
    api.get(`/reports/audit-logs?limit=${limit}&page=1`),

  // Get personal timetable (from your first export)
  getPersonalTimetable: () => api.get('/timetable/personal'),

  // Get report statistics (from your second export)
  getReportStats: () => api.get('/reports/stats'), // This might be duplicate of getStats

  // Get activity summary
  getActivitySummary: (params) => api.get('/reports/activity-summary', { params }),

  // Get enrollment trends
  getEnrollmentTrends: (params) => api.get('/reports/enrollment-trends', { params }),

  // Get attendance summary
  getAttendanceSummary: (params) => api.get('/reports/attendance-summary', { params }),
};