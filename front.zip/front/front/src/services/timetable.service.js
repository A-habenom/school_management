import api from './api';

export const timetableService = {
  // Get timetable with filters
  getTimetable: (params = {}) => {
    const queryParams = new URLSearchParams(params).toString();
    return api.get(`/timetable?${queryParams}`);
  },

  // Create timetable entry
  createTimetableEntry: (data) => api.post('/timetable', data),

  // Update timetable entry
  updateTimetableEntry: (id, data) => api.put(`/timetable/${id}`, data),

  // Delete timetable entry
  deleteTimetableEntry: (id) => api.delete(`/timetable/${id}`),

  // Get personal timetable (for teachers/students)
  getPersonalTimetable: () => api.get('/timetable/personal'),
};