import api from './api';

export const classesService = {
  // Classes
  getClasses: () => api.get('/classes'),
  createClass: (data) => api.post('/classes', data),

  // Class Subjects
  getAllocateSubject: (data) => api.post('/classes/allocate-subject', data),
  getClassSubjects: (params) => api.get('/classes/subjects', { params }),

  // Student Enrollment
  enrollStudent: (data) => api.post('/classes/enroll', data),
  getClassStudents: (params) => api.get('/classes/students', { params }),
};