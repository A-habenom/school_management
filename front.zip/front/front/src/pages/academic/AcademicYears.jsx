import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import Card, { CardHeader, CardTitle, CardContent } from '../../components/common/Card';
import Button from '../../components/common/Button';
import AcademicYearForm from '../../components/forms/AcademicYearForm';
import { 
  CalendarPlus, 
  CalendarCheck, 
  CalendarDays,
  Edit, 
  Trash2, 
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertCircle,
  X
} from 'lucide-react';
import { academicService } from '../../services/academic.service';

const AcademicYears = () => {
  const queryClient = useQueryClient();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editYear, setEditYear] = useState(null);

  // Fetch academic years
  const { 
    data: yearsData, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  // Set as current mutation
  const setCurrentMutation = useMutation({
    mutationFn: academicService.setCurrentAcademicYear,
    onSuccess: () => {
      toast.success('Academic year set as current');
      queryClient.invalidateQueries(['academic-years']);
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to set academic year as current');
    },
  });

  const handleSetCurrent = (id) => {
    if (confirm('Set this academic year as current? This will update all system records.')) {
      setCurrentMutation.mutate(id);
    }
  };

  const years = yearsData?.data || [];

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Academic Years</h1>
            <p className="text-gray-600 mt-1">Manage academic years and terms</p>
          </div>
        </div>
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-red-600">
              <AlertCircle className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-lg font-medium">Error loading academic years</h3>
              <p className="mt-2">{error.message}</p>
            </div>
            <Button onClick={() => refetch()} className="mt-4">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Academic Years</h1>
          <p className="text-gray-600 mt-1">Manage academic years and terms</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)}>
          <CalendarPlus className="h-4 w-4 mr-2" />
          Add Academic Year
        </Button>
      </div>

      {/* Academic Years List */}
      <Card>
        <CardHeader>
          <CardTitle>Academic Years ({years.length} total)</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-12 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading academic years...</p>
            </div>
          ) : years.length === 0 ? (
            <div className="text-center py-12">
              <CalendarDays className="h-12 w-12 text-gray-400 mx-auto" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">No academic years</h3>
              <p className="mt-2 text-gray-600">Get started by adding your first academic year.</p>
              <div className="mt-6">
                <Button onClick={() => setIsFormOpen(true)}>
                  <CalendarPlus className="h-4 w-4 mr-2" />
                  Add Academic Year
                </Button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Year
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Period
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Duration
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {years.map((year) => {
                    const startDate = new Date(year.start_date);
                    const endDate = new Date(year.end_date);
                    const durationDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
                    
                    return (
                      <tr key={year.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <div className={`p-2 rounded-lg ${year.is_current ? 'bg-blue-100' : 'bg-gray-100'}`}>
                              <CalendarDays className={`h-5 w-5 ${year.is_current ? 'text-blue-600' : 'text-gray-600'}`} />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{year.name}</div>
                              <div className="text-sm text-gray-500">ID: {year.id}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">
                            {startDate.toLocaleDateString()}
                          </div>
                          <div className="text-sm text-gray-600">
                            to {endDate.toLocaleDateString()}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {year.is_current ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Current
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                              <XCircle className="h-3 w-3 mr-1" />
                              Past
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">
                            {durationDays} days
                          </div>
                          <div className="text-xs text-gray-500">
                            ({Math.floor(durationDays / 30)} months)
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2">
                            {!year.is_current && (
                              <button
                                onClick={() => handleSetCurrent(year.id)}
                                className="text-blue-600 hover:text-blue-900 p-1 flex items-center text-sm"
                                title="Set as current"
                                disabled={setCurrentMutation.isLoading}
                              >
                                <CalendarCheck className="h-4 w-4 mr-1" />
                                Set Current
                              </button>
                            )}
                            <button
                              onClick={() => {
                                setEditYear(year);
                                setIsFormOpen(true);
                              }}
                              className="text-gray-600 hover:text-gray-900 p-1"
                              title="Edit"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              className="text-red-600 hover:text-red-900 p-1"
                              title="Delete"
                              onClick={() => {
                                if (confirm(`Delete academic year "${year.name}"? This action cannot be undone.`)) {
                                  toast.error('Delete functionality coming soon');
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Academic Year Form Modal */}
      <AcademicYearForm
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditYear(null);
        }}
        year={editYear}
      />
    </div>
  );
};

export default AcademicYears;