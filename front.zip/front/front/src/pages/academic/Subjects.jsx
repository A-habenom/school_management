import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import Card, { CardHeader, CardTitle, CardContent } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { 
  BookOpen, 
  BookOpenCheck,  // Changed from BookOpenPlus
  Edit, 
  Trash2, 
  Search,
  RefreshCw,
  AlertCircle,
  Hash,
  X  // Added this import
} from 'lucide-react';
import { academicService } from '../../services/academic.service';

const Subjects = () => {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [editSubject, setEditSubject] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    description: ''
  });

  // Fetch subjects
  const { 
    data: subjectsData, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['subjects'],
    queryFn: academicService.getSubjects,
  });

  // Create subject mutation
  const createMutation = useMutation({
    mutationFn: academicService.createSubject,
    onSuccess: () => {
      toast.success('Subject created successfully');
      queryClient.invalidateQueries(['subjects']);
      setIsCreating(false);
      setFormData({ name: '', code: '', description: '' });
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to create subject');
    },
  });

  // Update subject mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => academicService.updateSubject(id, data),
    onSuccess: () => {
      toast.success('Subject updated successfully');
      queryClient.invalidateQueries(['subjects']);
      setIsCreating(false);
      setEditSubject(null);
      setFormData({ name: '', code: '', description: '' });
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update subject');
    },
  });

  // Delete subject mutation
  const deleteMutation = useMutation({
    mutationFn: academicService.deleteSubject,
    onSuccess: () => {
      toast.success('Subject deleted successfully');
      queryClient.invalidateQueries(['subjects']);
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete subject');
    },
  });

  const handleDelete = (subject) => {
    if (confirm(`Delete subject "${subject.name}"? This action cannot be undone.`)) {
      deleteMutation.mutate(subject.id);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.code) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editSubject) {
      // Update existing subject
      updateMutation.mutate({ id: editSubject.id, data: formData });
    } else {
      // Create new subject
      createMutation.mutate(formData);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Initialize form when editing
  const handleEdit = (subject) => {
    setEditSubject(subject);
    setFormData({
      name: subject.name || '',
      code: subject.code || '',
      description: subject.description || ''
    });
    setIsCreating(true);
  };

  const subjects = subjectsData?.data || [];
  const filteredSubjects = subjects.filter(subject =>
    subject.name.toLowerCase().includes(search.toLowerCase()) ||
    subject.code.toLowerCase().includes(search.toLowerCase()) ||
    subject.description?.toLowerCase().includes(search.toLowerCase())
  );

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Subjects</h1>
            <p className="text-gray-600 mt-1">Manage all subjects in the curriculum</p>
          </div>
        </div>
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-red-600">
              <AlertCircle className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-lg font-medium">Error loading subjects</h3>
              <p className="mt-2">{error.message}</p>
            </div>
            <Button onClick={() => refetch()} className="mt-4">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Subjects</h1>
          <p className="text-gray-600 mt-1">Manage all subjects in the curriculum</p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <BookOpenCheck className="h-4 w-4 mr-2" />
          Add Subject
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1">
              <div className="relative max-w-md">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search subjects..."
                  className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={() => setSearch('')}>
                Clear Search
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Subjects List */}
      <Card>
        <CardHeader>
          <CardTitle>Subjects List ({subjects.length} total)</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-12 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading subjects...</p>
            </div>
          ) : filteredSubjects.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">
                {search ? 'No subjects found' : 'No subjects added'}
              </h3>
              <p className="mt-2 text-gray-600">
                {search ? 'Try a different search term' : 'Start by adding subjects to your curriculum.'}
              </p>
              {!search && (
                <div className="mt-6">
                  <Button onClick={() => setIsCreating(true)}>
                    <BookOpenCheck className="h-4 w-4 mr-2" />
                    Add Subject
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSubjects.map((subject) => (
                <div key={subject.id} className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-sm transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-2 rounded-lg mr-3">
                          <BookOpen className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{subject.name}</h3>
                          <div className="flex items-center mt-1">
                            <Hash className="h-3 w-3 text-gray-400 mr-1" />
                            <span className="text-sm text-gray-600">{subject.code}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleEdit(subject)}
                        className="text-gray-600 hover:text-gray-900 p-1"
                        title="Edit subject"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(subject)}
                        className="text-red-600 hover:text-red-900 p-1"
                        title="Delete subject"
                        disabled={deleteMutation.isLoading}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  {subject.description && (
                    <p className="text-sm text-gray-600 mt-3 line-clamp-2">
                      {subject.description}
                    </p>
                  )}
                  
                  <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      ID: {subject.id}
                    </span>
                    <span className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
                      Subject
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Subject Modal */}
      {isCreating && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">
                {editSubject ? 'Edit Subject' : 'Add New Subject'}
              </h2>
              <button
                onClick={() => {
                  setIsCreating(false);
                  setEditSubject(null);
                  setFormData({ name: '', code: '', description: '' });
                }}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="e.g., Mathematics, Physics"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Subject Code *
                  </label>
                  <input
                    type="text"
                    name="code"
                    value={formData.code}
                    onChange={handleChange}
                    placeholder="e.g., MATH101, PHY201"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows="3"
                    placeholder="Brief description of the subject..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsCreating(false);
                    setEditSubject(null);
                    setFormData({ name: '', code: '', description: '' });
                  }}
                  disabled={createMutation.isLoading || updateMutation.isLoading}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isLoading || updateMutation.isLoading}
                >
                  {(createMutation.isLoading || updateMutation.isLoading) 
                    ? 'Saving...' 
                    : editSubject 
                      ? 'Update Subject' 
                      : 'Create Subject'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Subjects;