import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import Card, { CardHeader, CardTitle, CardContent } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { 
  GraduationCap, 
  UserPlus, 
  BookOpen, 
  Users,
  Search,
  Filter,
  Edit,
  Trash2,
  Eye,
  MoreVertical,
  RefreshCw,
  AlertCircle,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';
import ClassForm from '../../components/forms/ClassForm';
import AllocateSubjectModal from '../../components/modals/AllocateSubjectModal';
import EnrollStudentModal from '../../components/modals/EnrollStudentModal';

const Classes = () => {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [academicYearFilter, setAcademicYearFilter] = useState('');
  const [isClassFormOpen, setIsClassFormOpen] = useState(false);
  const [isAllocateModalOpen, setIsAllocateModalOpen] = useState(false);
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'grid'

  // Fetch classes
  const { 
    data: classesData, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['classes', page, search, academicYearFilter],
    queryFn: () => classesService.getClasses(),
  });

  // Fetch academic years for filter
  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  // Delete class mutation
  const deleteMutation = useMutation({
    mutationFn: (id) => {
      // Note: Your backend might not have delete endpoint
      // This is a placeholder - adjust based on your API
      return Promise.reject('Delete endpoint not implemented');
    },
    onSuccess: () => {
      toast.success('Class deleted successfully');
      queryClient.invalidateQueries(['classes']);
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete class');
    },
  });

  const handleDelete = (classItem) => {
    if (confirm(`Delete class "${classItem.name}"? This will remove all associated data.`)) {
      deleteMutation.mutate(classItem.id);
    }
  };

  const classes = classesData?.data || [];
  const academicYears = academicYearsData?.data || [];
  const currentAcademicYear = academicYears.find(year => year.is_current);

  // Filter classes
  const filteredClasses = classes.filter(cls => {
    if (search && !cls.name.toLowerCase().includes(search.toLowerCase()) && 
        !cls.section?.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (academicYearFilter && cls.academic_year_id !== parseInt(academicYearFilter)) {
      return false;
    }
    return true;
  });

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Classes</h1>
            <p className="text-gray-600 mt-1">Manage classes and student enrollment</p>
          </div>
        </div>
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-red-600">
              <AlertCircle className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-lg font-medium">Error loading classes</h3>
              <p className="mt-2">{error.message}</p>
            </div>
            <Button onClick={() => refetch()} className="mt-4">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Classes</h1>
          <p className="text-gray-600 mt-1">Manage classes and student enrollment</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="outline"
            onClick={() => setIsEnrollModalOpen(true)}
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Enroll Student
          </Button>
          <Button 
            variant="outline"
            onClick={() => setIsAllocateModalOpen(true)}
          >
            <BookOpen className="h-4 w-4 mr-2" />
            Allocate Subject
          </Button>
          <Button onClick={() => setIsClassFormOpen(true)}>
            <GraduationCap className="h-4 w-4 mr-2" />
            Create Class
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-col md:flex-row md:items-center gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search classes..."
                  className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <div>
                  <select
                    value={academicYearFilter}
                    onChange={(e) => setAcademicYearFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">All Academic Years</option>
                    {academicYears.map(year => (
                      <option key={year.id} value={year.id}>
                        {year.name} {year.is_current && '(Current)'}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setViewMode('list')}
                    className={`px-3 py-2 ${viewMode === 'list' ? 'bg-gray-100 text-gray-900' : 'text-gray-600'}`}
                  >
                    List
                  </button>
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`px-3 py-2 ${viewMode === 'grid' ? 'bg-gray-100 text-gray-900' : 'text-gray-600'}`}
                  >
                    Grid
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearch('');
                  setAcademicYearFilter('');
                }}
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Classes Content */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>
              Classes ({filteredClasses.length} of {classes.length} total)
              {currentAcademicYear && (
                <span className="text-sm font-normal text-gray-600 ml-2">
                  • Current: {currentAcademicYear.name}
                </span>
              )}
            </CardTitle>
            <div className="text-sm text-gray-600">
              Showing {filteredClasses.length} classes
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="py-12 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading classes...</p>
            </div>
          ) : filteredClasses.length === 0 ? (
            <div className="text-center py-12">
              <GraduationCap className="h-12 w-12 text-gray-400 mx-auto" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">
                {search || academicYearFilter ? 'No classes found' : 'No classes created'}
              </h3>
              <p className="mt-2 text-gray-600">
                {search || academicYearFilter 
                  ? 'Try adjusting your search or filters.' 
                  : 'Create your first class to get started.'}
              </p>
              {!search && !academicYearFilter && (
                <div className="mt-6">
                  <Button onClick={() => setIsClassFormOpen(true)}>
                    <GraduationCap className="h-4 w-4 mr-2" />
                    Create Class
                  </Button>
                </div>
              )}
            </div>
          ) : viewMode === 'grid' ? (
            // Grid View
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredClasses.map(cls => (
                <div key={cls.id} className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-sm transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-2 rounded-lg mr-3">
                          <GraduationCap className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{cls.name}</h3>
                          <div className="text-sm text-gray-600">
                            Section: {cls.section || 'N/A'}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => {
                          setSelectedClass(cls);
                          // Navigate to class details
                          window.location.href = `/classes/${cls.id}`;
                        }}
                        className="text-gray-600 hover:text-gray-900 p-1"
                        title="View details"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedClass(cls);
                          setIsClassFormOpen(true);
                        }}
                        className="text-gray-600 hover:text-gray-900 p-1"
                        title="Edit class"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(cls)}
                        className="text-red-600 hover:text-red-900 p-1"
                        title="Delete class"
                        disabled={deleteMutation.isLoading}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Capacity:</span>
                      <span className="font-medium text-gray-900">{cls.capacity || 30} students</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Academic Year:</span>
                      <span className="font-medium text-gray-900">
                        {cls.academic_year_name || 'N/A'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Class Teacher:</span>
                      <span className="font-medium text-gray-900">
                        {cls.teacher_first_name 
                          ? `${cls.teacher_first_name} ${cls.teacher_last_name}` 
                          : 'Not assigned'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <Button
                        variant="outline"
                        size="small"
                        onClick={() => {
                          setSelectedClass(cls);
                          setIsEnrollModalOpen(true);
                        }}
                        className="w-full mr-2"
                      >
                        <UserPlus className="h-3 w-3 mr-1" />
                        Enroll
                      </Button>
                      <Button
                        variant="outline"
                        size="small"
                        onClick={() => {
                          setSelectedClass(cls);
                          setIsAllocateModalOpen(true);
                        }}
                        className="w-full"
                      >
                        <BookOpen className="h-3 w-3 mr-1" />
                        Subjects
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            // List View
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Class
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Academic Year
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Capacity
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Class Teacher
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredClasses.map(cls => (
                    <tr key={cls.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="bg-blue-100 p-2 rounded-lg mr-3">
                            <GraduationCap className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {cls.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              Section: {cls.section || 'N/A'}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          {cls.academic_year_name || 'N/A'}
                        </div>
                        {cls.academic_year_id === currentAcademicYear?.id && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800 mt-1">
                            Current
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          {cls.capacity || 30} students
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                          <div 
                            className="bg-blue-600 h-1.5 rounded-full" 
                            style={{ width: '65%' }}
                          ></div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">
                          {cls.teacher_first_name 
                            ? `${cls.teacher_first_name} ${cls.teacher_last_name}` 
                            : 'Not assigned'}
                        </div>
                        {cls.teacher_first_name && (
                          <div className="text-xs text-gray-500">
                            Class Teacher
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => {
                              setSelectedClass(cls);
                              setIsEnrollModalOpen(true);
                            }}
                            className="text-blue-600 hover:text-blue-900 p-1 flex items-center text-sm"
                            title="Enroll students"
                          >
                            <UserPlus className="h-4 w-4 mr-1" />
                            Enroll
                          </button>
                          <button
                            onClick={() => {
                              setSelectedClass(cls);
                              setIsAllocateModalOpen(true);
                            }}
                            className="text-purple-600 hover:text-purple-900 p-1 flex items-center text-sm"
                            title="Allocate subjects"
                          >
                            <BookOpen className="h-4 w-4 mr-1" />
                            Subjects
                          </button>
                          <button
                            onClick={() => {
                              setSelectedClass(cls);
                              setIsClassFormOpen(true);
                            }}
                            className="text-gray-600 hover:text-gray-900 p-1"
                            title="Edit class"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {filteredClasses.length > 10 && (
            <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200">
              <div className="text-sm text-gray-700">
                Showing {filteredClasses.length} classes
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <span className="px-3 py-1 text-sm text-gray-700">
                  Page {page}
                </span>
                <Button
                  variant="outline"
                  onClick={() => setPage(p => p + 1)}
                  disabled={filteredClasses.length < 10}
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      <ClassForm
        isOpen={isClassFormOpen}
        onClose={() => {
          setIsClassFormOpen(false);
          setSelectedClass(null);
        }}
        classData={selectedClass}
      />

      <AllocateSubjectModal
        isOpen={isAllocateModalOpen}
        onClose={() => {
          setIsAllocateModalOpen(false);
          setSelectedClass(null);
        }}
        selectedClass={selectedClass}
      />

      <EnrollStudentModal
        isOpen={isEnrollModalOpen}
        onClose={() => {
          setIsEnrollModalOpen(false);
          setSelectedClass(null);
        }}
        selectedClass={selectedClass}
      />
    </div>
  );
};

export default Classes;