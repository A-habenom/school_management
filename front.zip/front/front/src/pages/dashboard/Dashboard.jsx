import { useQuery } from '@tanstack/react-query';
import { useAuth } from '../../contexts/AuthContext';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { 
  Users, 
  GraduationCap, 
  BookOpen, 
  Calendar, 
  BarChart3, 
  TrendingUp,
  AlertCircle,
  Clock,
  RefreshCw,
  CalendarDays,
  UserCheck,
  BookCheck,
  FileText,
  CheckCircle,
  XCircle,
  Bell,
  MessageSquare,
  Home,
  DollarSign,
  Bookmark
} from 'lucide-react';
import { FileText as Assignment} from 'lucide-react';
import { dashboardService } from '../../services/dashboard.service';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';
import { timetableService } from '../../services/timetable.service';

const Dashboard = () => {
  const { user } = useAuth();

  // Fetch data based on user role
  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: dashboardService.getStats,
    staleTime: 5 * 60 * 1000,
    enabled: user?.role === 'admin', // Only admins need full stats
  });

  const { data: personalTimetable, isLoading: timetableLoading } = useQuery({
    queryKey: ['personal-timetable'],
    queryFn: timetableService.getPersonalTimetable,
    enabled: user?.role !== 'admin', // Students & teachers need personal timetable
  });

  const { data: classesData } = useQuery({
    queryKey: ['classes'],
    queryFn: classesService.getClasses,
    enabled: user?.role === 'admin' || user?.role === 'teacher',
  });

  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  const stats = statsData?.data || {};
  const timetable = personalTimetable?.data?.raw || [];
  const classes = classesData?.data || [];
  const academicYears = academicYearsData?.data || [];
  const currentAcademicYear = academicYears.find(year => year.is_current);

  // Get today's day
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  const todayTimetable = timetable.filter(entry => entry.day_of_week === today);

  // Admin Dashboard Stats
  const adminStats = [
    { 
      label: 'Total Students', 
      value: stats.users?.students || '0', 
      icon: Users, 
      color: 'bg-blue-500',
      change: '+12%' 
    },
    { 
      label: 'Total Teachers', 
      value: stats.users?.teachers || '0', 
      icon: GraduationCap, 
      color: 'bg-green-500',
      change: '+5%' 
    },
    { 
      label: 'Active Classes', 
      value: stats.academic?.classes || '0', 
      icon: BookOpen, 
      color: 'bg-purple-500',
      change: '+8%' 
    },
    { 
      label: 'Total Subjects', 
      value: stats.academic?.subjects || '0', 
      icon: BookCheck, 
      color: 'bg-orange-500',
      change: '+3%' 
    },
  ];

  // Teacher Dashboard Stats
  const teacherStats = [
    { 
      label: 'My Classes', 
      value: classes.filter(c => c.class_teacher_id === user?.id).length || '0', 
      icon: BookOpen, 
      color: 'bg-blue-500' 
    },
    { 
      label: 'Total Students', 
      value: '45', // This would come from API
      icon: Users, 
      color: 'bg-green-500' 
    },
    { 
      label: 'Today\'s Classes', 
      value: todayTimetable.length || '0', 
      icon: Calendar, 
      color: 'bg-purple-500' 
    },
    { 
      label: 'Assignments Due', 
      value: '3', // This would come from API
      icon: Assignment, 
      color: 'bg-orange-500' 
    },
  ];

  // Student Dashboard Stats
  const studentStats = [
    { 
      label: 'My Class', 
      value: '10A', // This would come from API
      icon: Home, 
      color: 'bg-blue-500' 
    },
    { 
      label: 'Attendance', 
      value: '92%', // This would come from API
      icon: CheckCircle, 
      color: 'bg-green-500' 
    },
    { 
      label: 'Today\'s Classes', 
      value: todayTimetable.length || '0', 
      icon: Calendar, 
      color: 'bg-purple-500' 
    },
    { 
      label: 'Assignments Due', 
      value: '2', // This would come from API
      icon: Assignment, 
      color: 'bg-orange-500' 
    },
  ];

  // Choose stats based on role
  const dashboardStats = user?.role === 'admin' ? adminStats : 
                        user?.role === 'teacher' ? teacherStats : 
                        studentStats;

  // Admin Quick Actions
  const adminQuickActions = [
    { label: 'Manage Users', icon: Users, path: '/users', color: 'text-blue-600' },
    { label: 'Create Class', icon: BookOpen, path: '/classes', color: 'text-green-600' },
    { label: 'Schedule', icon: Calendar, path: '/timetable', color: 'text-purple-600' },
    { label: 'Reports', icon: BarChart3, path: '/reports', color: 'text-orange-600' },
  ];

  // Teacher Quick Actions
  const teacherQuickActions = [
    { label: 'My Classes', icon: BookOpen, path: '/classes', color: 'text-blue-600' },
    { label: 'Timetable', icon: Calendar, path: '/timetable', color: 'text-green-600' },
    { label: 'Attendance', icon: CheckCircle, path: '#', color: 'text-purple-600' },
    { label: 'Assignments', icon: Assignment, path: '#', color: 'text-orange-600' },
  ];

  // Student Quick Actions
  const studentQuickActions = [
    { label: 'My Timetable', icon: Calendar, path: '/timetable', color: 'text-blue-600' },
    { label: 'Assignments', icon: Assignment, path: '#', color: 'text-green-600' },
    { label: 'Grades', icon: BookCheck, path: '#', color: 'text-purple-600' },
    { label: 'Attendance', icon: CheckCircle, path: '#', color: 'text-orange-600' },
  ];

  const quickActions = user?.role === 'admin' ? adminQuickActions : 
                      user?.role === 'teacher' ? teacherQuickActions : 
                      studentQuickActions;

  // Role-specific welcome messages
  const welcomeMessages = {
    admin: `Welcome back, Administrator ${user?.first_name}!`,
    teacher: `Good to see you, ${user?.first_name}! Ready for today's classes?`,
    student: `Welcome back, ${user?.first_name}! How's your learning going?`,
    staff: `Welcome back, ${user?.first_name}!`
  };

  const welcomeMessage = welcomeMessages[user?.role] || `Welcome back, ${user?.first_name}!`;

  // Role-specific descriptions
  const roleDescriptions = {
    admin: 'Manage your school system efficiently',
    teacher: 'Track your classes and students',
    student: 'Access your learning materials and schedule',
    staff: 'Handle administrative tasks'
  };

  const isLoading = statsLoading || timetableLoading;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-6 text-white">
          <h1 className="text-2xl font-bold">Loading your dashboard...</h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent>
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="h-8 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Banner - Role Specific */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 dark:from-blue-700 dark:to-blue-900 rounded-2xl p-6 text-white">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">{welcomeMessage}</h1>
            <p className="mt-2 text-blue-100">
              {roleDescriptions[user?.role]}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-4">
              <div className="bg-blue-500 bg-opacity-30 px-4 py-2 rounded-lg">
                <p className="text-sm">
                  Role: <span className="font-medium capitalize">{user?.role}</span>
                </p>
              </div>
              {currentAcademicYear && (
                <div className="bg-blue-500 bg-opacity-30 px-4 py-2 rounded-lg">
                  <p className="text-sm flex items-center">
                    <CalendarDays className="h-4 w-4 mr-2" />
                    Academic Year: {currentAcademicYear.name}
                  </p>
                </div>
              )}
              {user?.role === 'admin' && stats.users?.total && (
                <div className="bg-blue-500 bg-opacity-30 px-4 py-2 rounded-lg">
                  <p className="text-sm">
                    Total Users: <span className="font-medium">{stats.users.total}</span>
                  </p>
                </div>
              )}
            </div>
          </div>
          <Button 
            variant="outline" 
            size="small"
            className="bg-white bg-opacity-20 hover:bg-opacity-30 border-white text-white"
            onClick={() => window.location.reload()}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {dashboardStats.map((stat, index) => (
          <Card key={index} hover>
            <CardContent className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                {stat.change && (
                  <p className="text-sm text-green-600 mt-1 flex items-center">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    {stat.change}
                  </p>
                )}
              </div>
              <div className={`${stat.color} p-3 rounded-xl`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {quickActions.map((action, index) => (
                  <Button 
                    key={index}
                    variant="outline" 
                    className="flex flex-col items-center justify-center h-24"
                    onClick={() => window.location.href = action.path}
                  >
                    <action.icon className={`h-8 w-8 ${action.color} mb-2`} />
                    <span className="text-sm">{action.label}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Role-specific content */}
          {user?.role === 'admin' && (
            <Card>
              <CardHeader>
                <CardTitle>System Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Database Status</span>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <UserCheck className="h-3 w-3 mr-1" />
                      Online
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Storage Usage</span>
                    <span className="text-sm font-medium text-gray-900">65% used</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '65%' }}></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Active Sessions</span>
                    <span className="text-sm font-medium text-gray-900">24 users online</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {user?.role === 'teacher' && (
            <Card>
              <CardHeader>
                <CardTitle>Today's Classes</CardTitle>
              </CardHeader>
              <CardContent>
                {todayTimetable.length > 0 ? (
                  <div className="space-y-4">
                    {todayTimetable.map((entry, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">{entry.subject_name}</h4>
                          <p className="text-sm text-gray-600">{entry.class_name} • {entry.start_time} - {entry.end_time}</p>
                        </div>
                        <div className="bg-blue-50 px-3 py-1 rounded-full">
                          <p className="text-sm font-medium text-blue-700">{entry.room_number || 'Room TBD'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 text-gray-400 mx-auto" />
                    <p className="mt-4 text-gray-600">No classes scheduled for today</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {user?.role === 'student' && (
            <Card>
              <CardHeader>
                <CardTitle>Today's Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                {todayTimetable.length > 0 ? (
                  <div className="space-y-4">
                    {todayTimetable.map((entry, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">{entry.subject_name}</h4>
                          <p className="text-sm text-gray-600">{entry.start_time} - {entry.end_time}</p>
                          <p className="text-sm text-gray-500">Teacher: {entry.teacher_first_name}</p>
                        </div>
                        <div className="bg-blue-50 px-3 py-1 rounded-full">
                          <p className="text-sm font-medium text-blue-700">{entry.room_number || 'Room TBD'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 text-gray-400 mx-auto" />
                    <p className="mt-4 text-gray-600">No classes today. Enjoy your study time!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Notifications */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Notifications</CardTitle>
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">3</span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                  <Bell className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">System Update</p>
                    <p className="text-xs text-gray-600 mt-1">New features added to the platform</p>
                  </div>
                </div>
                
                {user?.role === 'teacher' && (
                  <div className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                    <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Assignment Due</p>
                      <p className="text-xs text-gray-600 mt-1">3 assignments need grading</p>
                    </div>
                  </div>
                )}

                {user?.role === 'student' && (
                  <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">New Grade Posted</p>
                      <p className="text-xs text-gray-600 mt-1">Mathematics: 92% (A)</p>
                    </div>
                  </div>
                )}

                <div className="text-sm text-gray-600 p-3">
                  <p className="font-medium mb-2">Upcoming Events:</p>
                  <p>• Parent-teacher meeting (Friday)</p>
                  <p className="mt-1">• Sports day next week</p>
                  <p className="mt-1">• Report cards available Friday</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View All Notifications
              </Button>
            </CardFooter>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg">
                  <Clock className="h-4 w-4 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-900">
                      You logged in at {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">Today</p>
                  </div>
                </div>
                
                {user?.role === 'teacher' && (
                  <div className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg">
                    <FileText className="h-4 w-4 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-sm text-gray-900">Posted Mathematics assignment</p>
                      <p className="text-xs text-gray-500 mt-1">Yesterday</p>
                    </div>
                  </div>
                )}

                {user?.role === 'student' && (
                  <div className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg">
                    <BookCheck className="h-4 w-4 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-sm text-gray-900">Submitted Physics homework</p>
                      <p className="text-xs text-gray-500 mt-1">Yesterday</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quick Links */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Links</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {user?.role === 'admin' && (
                  <>
                    <a href="/academic/years" className="flex items-center p-2 hover:bg-gray-50 rounded-lg">
                      <CalendarDays className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-700">Academic Years</span>
                    </a>
                    <a href="/academic/subjects" className="flex items-center p-2 hover:bg-gray-50 rounded-lg">
                      <BookOpen className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-700">Subjects</span>
                    </a>
                  </>
                )}
                <a href="/timetable" className="flex items-center p-2 hover:bg-gray-50 rounded-lg">
                  <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-700">Timetable</span>
                </a>
                <a href="/reports" className="flex items-center p-2 hover:bg-gray-50 rounded-lg">
                  <BarChart3 className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-700">Reports</span>
                </a>
                <a href="/settings" className="flex items-center p-2 hover:bg-gray-50 rounded-lg">
                  <Bell className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-700">Settings</span>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;