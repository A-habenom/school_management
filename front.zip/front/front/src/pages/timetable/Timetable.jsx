import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import Card, { CardHeader, CardTitle, CardContent } from '../../components/common/Card';
import Button from '../../components/common/Button';
import TimetableForm from '../../components/forms/TimetableForm';
import { 
  Calendar, 
  CalendarPlus, 
  Clock, 
  BookOpen, 
  Users,
  Filter,
  Edit,
  Trash2,
  RefreshCw,
  AlertCircle,
  Grid3x3,
  List,
  ChevronLeft,
  ChevronRight,
  School
} from 'lucide-react';
import { timetableService } from '../../services/timetable.service';
import { classesService } from '../../services/classes.service';
import { academicService } from '../../services/academic.service';

const Timetable = () => {
  const queryClient = useQueryClient();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [view, setView] = useState('weekly'); // 'weekly' or 'daily'
  const [filters, setFilters] = useState({
    class_id: '',
    teacher_id: '',
    academic_year_id: '',
    day_of_week: ''
  });

  // Days of week
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const timeSlots = [
    '08:00', '09:00', '10:00', '11:00', '12:00', 
    '13:00', '14:00', '15:00', '16:00', '17:00'
  ];

  // Fetch timetable
  const { 
    data: timetableData, 
    isLoading, 
    error,
    refetch 
  } = useQuery({
    queryKey: ['timetable', filters],
    queryFn: () => timetableService.getTimetable(filters),
  });

  // Fetch classes for filter
  const { data: classesData } = useQuery({
    queryKey: ['classes'],
    queryFn: classesService.getClasses,
  });

  // Fetch academic years for filter
  const { data: academicYearsData } = useQuery({
    queryKey: ['academic-years'],
    queryFn: academicService.getAcademicYears,
  });

  // Delete timetable entry mutation
  const deleteMutation = useMutation({
    mutationFn: timetableService.deleteTimetableEntry,
    onSuccess: () => {
      toast.success('Timetable entry deleted successfully');
      queryClient.invalidateQueries(['timetable']);
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete timetable entry');
    },
  });

  const handleDelete = (entry) => {
    if (confirm(`Delete timetable entry for ${entry.subject_name} on ${entry.day_of_week}?`)) {
      deleteMutation.mutate(entry.id);
    }
  };

  const handleFilterChange = (name, value) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      class_id: '',
      teacher_id: '',
      academic_year_id: '',
      day_of_week: ''
    });
  };

  const timetable = timetableData?.data?.raw || [];
  const classes = classesData?.data || [];
  const academicYears = academicYearsData?.data || [];
  const currentAcademicYear = academicYears.find(year => year.is_current);

  // Group timetable by day for weekly view
  const groupedTimetable = timetable.reduce((acc, entry) => {
    if (!acc[entry.day_of_week]) {
      acc[entry.day_of_week] = [];
    }
    acc[entry.day_of_week].push(entry);
    return acc;
  }, {});

  // Find conflicts
  const findConflicts = () => {
    const conflicts = [];
    const entriesByDay = {};
    
    timetable.forEach(entry => {
      if (!entriesByDay[entry.day_of_week]) {
        entriesByDay[entry.day_of_week] = [];
      }
      entriesByDay[entry.day_of_week].push(entry);
    });

    Object.values(entriesByDay).forEach(dayEntries => {
      dayEntries.sort((a, b) => a.start_time.localeCompare(b.start_time));
      
      for (let i = 0; i < dayEntries.length - 1; i++) {
        const current = dayEntries[i];
        const next = dayEntries[i + 1];
        
        if (current.end_time > next.start_time) {
          conflicts.push({
            type: 'time',
            entries: [current, next],
            message: `Time conflict: ${current.subject_name} and ${next.subject_name} overlap`
          });
        }
        
        // Check for same teacher at same time
        if (current.teacher_id === next.teacher_id && 
            current.start_time === next.start_time) {
          conflicts.push({
            type: 'teacher',
            entries: [current, next],
            message: `Teacher conflict: ${current.teacher_first_name} is scheduled for two classes at ${current.start_time}`
          });
        }
      }
    });

    return conflicts;
  };

  const conflicts = findConflicts();

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Timetable</h1>
            <p className="text-gray-600 mt-1">Manage class schedules and timetables</p>
          </div>
        </div>
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-red-600">
              <AlertCircle className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-lg font-medium">Error loading timetable</h3>
              <p className="mt-2">{error.message}</p>
            </div>
            <Button onClick={() => refetch()} className="mt-4">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Timetable</h1>
          <p className="text-gray-600 mt-1">Manage class schedules and timetables</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="outline"
            onClick={() => setView(view === 'weekly' ? 'daily' : 'weekly')}
          >
            {view === 'weekly' ? (
              <>
                <List className="h-4 w-4 mr-2" />
                Daily View
              </>
            ) : (
              <>
                <Grid3x3 className="h-4 w-4 mr-2" />
                Weekly View
              </>
            )}
          </Button>
          <Button onClick={() => setIsFormOpen(true)}>
            <CalendarPlus className="h-4 w-4 mr-2" />
            Add Schedule
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <div className="flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Filters</h3>
              <Button 
                variant="outline" 
                size="small"
                onClick={clearFilters}
              >
                Clear All
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Class
                </label>
                <select
                  value={filters.class_id}
                  onChange={(e) => handleFilterChange('class_id', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">All Classes</option>
                  {classes.map(cls => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name} {cls.section && `(${cls.section})`}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Academic Year
                </label>
                <select
                  value={filters.academic_year_id}
                  onChange={(e) => handleFilterChange('academic_year_id', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">All Years</option>
                  {academicYears.map(year => (
                    <option key={year.id} value={year.id}>
                      {year.name} {year.is_current && '(Current)'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Day of Week
                </label>
                <select
                  value={filters.day_of_week}
                  onChange={(e) => handleFilterChange('day_of_week', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">All Days</option>
                  {daysOfWeek.map(day => (
                    <option key={day} value={day}>{day}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  View Mode
                </label>
                <div className="flex border border-gray-300 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setView('weekly')}
                    className={`flex-1 px-3 py-2 text-sm ${view === 'weekly' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}
                  >
                    Weekly
                  </button>
                  <button
                    onClick={() => setView('daily')}
                    className={`flex-1 px-3 py-2 text-sm ${view === 'daily' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}
                  >
                    Daily
                  </button>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Conflict Alerts */}
      {conflicts.length > 0 && (
        <Card className="border-yellow-300 border-2">
          <CardContent className="p-4">
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 text-yellow-600 mr-3 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium text-yellow-800">Schedule Conflicts Detected</h4>
                <ul className="mt-2 space-y-1">
                  {conflicts.slice(0, 3).map((conflict, index) => (
                    <li key={index} className="text-sm text-yellow-700">
                      • {conflict.message}
                    </li>
                  ))}
                </ul>
                {conflicts.length > 3 && (
                  <p className="text-sm text-yellow-600 mt-2">
                    ...and {conflicts.length - 3} more conflicts
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Timetable Content */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>
              {view === 'weekly' ? 'Weekly Timetable' : 'Daily Schedule'}
              {currentAcademicYear && (
                <span className="text-sm font-normal text-gray-600 ml-2">
                  • Current: {currentAcademicYear.name}
                </span>
              )}
            </CardTitle>
            <div className="text-sm text-gray-600">
              {timetable.length} entries • {conflicts.length} conflicts
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="py-12 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading timetable...</p>
            </div>
          ) : timetable.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">No timetable entries</h3>
              <p className="mt-2 text-gray-600">
                {Object.keys(filters).some(key => filters[key]) 
                  ? 'No entries match your filters' 
                  : 'Create your first timetable schedule.'}
              </p>
              {!Object.keys(filters).some(key => filters[key]) && (
                <div className="mt-6">
                  <Button onClick={() => setIsFormOpen(true)}>
                    <CalendarPlus className="h-4 w-4 mr-2" />
                    Add Schedule
                  </Button>
                </div>
              )}
            </div>
          ) : view === 'weekly' ? (
            // Weekly View - Grid
            <div className="overflow-x-auto">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr>
                    <th className="border border-gray-300 bg-gray-50 px-4 py-3 text-left text-sm font-medium text-gray-700">
                      Time
                    </th>
                    {daysOfWeek.map(day => (
                      <th key={day} className="border border-gray-300 bg-gray-50 px-4 py-3 text-center text-sm font-medium text-gray-700">
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {timeSlots.map(timeSlot => (
                    <tr key={timeSlot}>
                      <td className="border border-gray-300 bg-gray-50 px-4 py-3 text-center text-sm font-medium text-gray-700 sticky left-0 z-10">
                        {timeSlot}
                      </td>
                      {daysOfWeek.map(day => {
                        const entriesForSlot = timetable.filter(entry => 
                          entry.day_of_week === day && 
                          entry.start_time.startsWith(timeSlot.substring(0, 2))
                        );
                        
                        return (
                          <td key={`${day}-${timeSlot}`} className="border border-gray-300 p-1 min-w-[180px] h-24">
                            {entriesForSlot.map(entry => (
                              <div
                                key={entry.id}
                                className="bg-blue-50 border border-blue-200 rounded p-2 mb-1 hover:bg-blue-100 cursor-pointer group relative"
                                onClick={() => {
                                  setSelectedEntry(entry);
                                  setIsFormOpen(true);
                                }}
                              >
                                <div className="flex items-start justify-between">
                                  <div className="flex-1">
                                    <div className="font-medium text-blue-800 text-sm">
                                      {entry.subject_name}
                                    </div>
                                    <div className="text-xs text-blue-600 mt-1">
                                      {entry.class_name}
                                    </div>
                                    <div className="text-xs text-gray-500 mt-1">
                                      {entry.start_time} - {entry.end_time}
                                    </div>
                                  </div>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleDelete(entry);
                                    }}
                                    className="opacity-0 group-hover:opacity-100 text-red-600 hover:text-red-800 p-1"
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            // Daily View - List
            <div className="space-y-6">
              {daysOfWeek.map(day => {
                const dayEntries = groupedTimetable[day] || [];
                if (dayEntries.length === 0) return null;
                
                return (
                  <div key={day} className="border border-gray-200 rounded-lg overflow-hidden">
                    <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                      <h3 className="font-medium text-gray-900">{day}</h3>
                      <p className="text-sm text-gray-600">
                        {dayEntries.length} classes scheduled
                      </p>
                    </div>
                    <div className="divide-y divide-gray-100">
                      {dayEntries.map(entry => (
                        <div 
                          key={entry.id} 
                          className="px-6 py-4 hover:bg-gray-50 group flex items-center justify-between"
                        >
                          <div className="flex items-center space-x-4">
                            <div className="bg-blue-100 p-2 rounded-lg">
                              <Clock className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <div className="flex items-center space-x-3">
                                <h4 className="font-medium text-gray-900">
                                  {entry.subject_name} ({entry.subject_code})
                                </h4>
                                <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded">
                                  {entry.start_time} - {entry.end_time}
                                </span>
                              </div>
                              <div className="text-sm text-gray-600 mt-1">
                                <span className="flex items-center">
                                  <School className="h-3 w-3 mr-1" />
                                  {entry.class_name} • Room: {entry.room_number || 'N/A'}
                                </span>
                                <span className="flex items-center mt-1">
                                  <Users className="h-3 w-3 mr-1" />
                                  {entry.teacher_first_name} {entry.teacher_last_name}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => {
                                setSelectedEntry(entry);
                                setIsFormOpen(true);
                              }}
                              className="text-gray-600 hover:text-gray-900 p-1"
                              title="Edit schedule"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(entry)}
                              className="text-red-600 hover:text-red-900 p-1"
                              title="Delete schedule"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Timetable Form Modal */}
      <TimetableForm
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setSelectedEntry(null);
        }}
        entry={selectedEntry}
      />
    </div>
  );
};

export default Timetable;