const ReportChart = ({ type = 'bar', data, title, height = 300 }) => {
  // Simple chart component - in a real app, you'd use a library like Chart.js or Recharts
  
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-gray-500">No data available</p>
      </div>
    );
  }

  if (type === 'bar') {
    const maxValue = Math.max(...data.map(item => item.value));
    
    return (
      <div className="space-y-4">
        {title && <h3 className="font-medium text-gray-900">{title}</h3>}
        <div className="space-y-2">
          {data.map((item, index) => (
            <div key={index} className="flex items-center">
              <div className="w-32 text-sm text-gray-600 truncate">{item.label}</div>
              <div className="flex-1 ml-4">
                <div className="flex items-center">
                  <div 
                    className="bg-blue-600 h-6 rounded"
                    style={{ width: `${(item.value / maxValue) * 100}%` }}
                  ></div>
                  <span className="ml-2 text-sm font-medium text-gray-900">
                    {item.value}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (type === 'pie') {
    const total = data.reduce((sum, item) => sum + item.value, 0);
    
    return (
      <div className="space-y-4">
        {title && <h3 className="font-medium text-gray-900">{title}</h3>}
        <div className="space-y-2">
          {data.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center">
                <div 
                  className="w-3 h-3 rounded-full mr-2"
                  style={{ backgroundColor: item.color || '#3b82f6' }}
                ></div>
                <span className="text-sm text-gray-600">{item.label}</span>
              </div>
              <div className="text-sm font-medium text-gray-900">
                {item.value} ({Math.round((item.value / total) * 100)}%)
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center h-full">
      <p className="text-gray-500">Chart type not supported</p>
    </div>
  );
};

export default ReportChart;