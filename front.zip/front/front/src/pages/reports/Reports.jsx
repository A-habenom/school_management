import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import Card, { CardHeader, CardTitle, CardContent, CardFooter } from '../../components/common/Card';
import Button from '../../components/common/Button';
import { 
  BarChart3, 
  Download, 
  FileText, 
  Users, 
  GraduationCap, 
  Calendar,
  TrendingUp,
  PieChart,
  Filter,
  RefreshCw,
  AlertCircle,
  Clock,
  BookOpen,
  DollarSign,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { dashboardService } from '../../services/dashboard.service';
import { reportService } from '../../services/report.service';

const Reports = () => {
  const [expandedSection, setExpandedSection] = useState('overview');
  const [selectedReport, setSelectedReport] = useState(null);
  const [reportFilters, setReportFilters] = useState({
    start_date: '',
    end_date: '',
    class_id: '',
    report_type: 'system_stats'
  });

  // Fetch system stats for reports
  const { 
    data: statsData, 
    isLoading: statsLoading,
    error: statsError,
    refetch: refetchStats
  } = useQuery({
    queryKey: ['system-stats'],
    queryFn: dashboardService.getStats,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch audit logs for activity report
  const { 
    data: auditLogsData,
    isLoading: auditLogsLoading
  } = useQuery({
    queryKey: ['audit-logs-report'],
    queryFn: () => dashboardService.getRecentActivities(50),
  });

  // Fetch generated reports
  const { 
    data: generatedReportsData,
    isLoading: generatedReportsLoading
  } = useQuery({
    queryKey: ['generated-reports'],
    queryFn: () => reportService.getReports(),
  });

  const stats = statsData?.data || {};
  const auditLogs = auditLogsData?.data || [];
  const generatedReports = generatedReportsData?.data || [];

  const handleGenerateReport = (type) => {
    toast.success(`Generating ${type.replace('_', ' ')} report...`);
    // In a real app, this would call an API to generate the report
    setTimeout(() => {
      toast.success(`${type.replace('_', ' ')} report generated successfully!`);
    }, 2000);
  };

  const handleDownloadReport = (report) => {
    toast.success(`Downloading ${report.report_type} report...`);
    // In a real app, this would download the file
  };

  const handleFilterChange = (name, value) => {
    setReportFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const toggleSection = (section) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  if (statsError) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
            <p className="text-gray-600 mt-1">View and generate system reports</p>
          </div>
        </div>
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-red-600">
              <AlertCircle className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-lg font-medium">Error loading reports</h3>
              <p className="mt-2">{statsError.message}</p>
            </div>
            <Button onClick={() => refetchStats()} className="mt-4">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Report types
  const reportTypes = [
    { 
      id: 'student_performance', 
      name: 'Student Performance', 
      description: 'Academic performance and grades analysis',
      icon: GraduationCap,
      color: 'bg-blue-500'
    },
    { 
      id: 'attendance', 
      name: 'Attendance Report', 
      description: 'Student and teacher attendance records',
      icon: Users,
      color: 'bg-green-500'
    },
    { 
      id: 'financial', 
      name: 'Financial Report', 
      description: 'Fee collections and financial statements',
      icon: DollarSign,
      color: 'bg-purple-500'
    },
    { 
      id: 'class_performance', 
      name: 'Class Performance', 
      description: 'Class-wise academic performance',
      icon: BookOpen,
      color: 'bg-orange-500'
    },
    { 
      id: 'teacher_performance', 
      name: 'Teacher Performance', 
      description: 'Teacher workload and performance metrics',
      icon: Users,
      color: 'bg-red-500'
    },
    { 
      id: 'library', 
      name: 'Library Report', 
      description: 'Book issues and returns analysis',
      icon: FileText,
      color: 'bg-indigo-500'
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-600 mt-1">View and generate system reports</p>
        </div>
        <Button onClick={() => handleGenerateReport('system_stats')}>
          <BarChart3 className="h-4 w-4 mr-2" />
          Generate Report
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card hover>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Reports</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">
                  {generatedReports.length}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  +12% this month
                </p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card hover>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Students</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">
                  {stats.users?.students || '0'}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {stats.enrollmentStats?.[0]?.student_count || '0'} new this month
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <Users className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card hover>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Teachers</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">
                  {stats.users?.teachers || '0'}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  Avg: {stats.teacherWorkload?.[0]?.subjects_count || '0'} subjects
                </p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <GraduationCap className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card hover>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600">Classes Running</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">
                  {stats.academic?.classes || '0'}
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {stats.subjects?.total || '0'} subjects total
                </p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <Calendar className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Report Types */}
        <div className="lg:col-span-2 space-y-6">
          {/* Report Types */}
          <Card>
            <CardHeader>
              <CardTitle>Available Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {reportTypes.map(reportType => (
                  <div 
                    key={reportType.id}
                    className={`border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-sm transition-all cursor-pointer ${
                      selectedReport === reportType.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedReport(reportType.id)}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`${reportType.color} p-2 rounded-lg`}>
                        <reportType.icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{reportType.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">{reportType.description}</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleGenerateReport(reportType.id);
                        }}
                      >
                        Generate
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* System Overview Report */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>System Overview</CardTitle>
                <button
                  onClick={() => toggleSection('overview')}
                  className="text-gray-500 hover:text-gray-700"
                >
                  {expandedSection === 'overview' ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>
              </div>
            </CardHeader>
            {expandedSection === 'overview' && (
              <CardContent>
                <div className="space-y-6">
                  {/* User Distribution */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">User Distribution</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Students</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-32 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ 
                                width: `${(stats.users?.students / (stats.users?.total || 1)) * 100}%` 
                              }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {stats.users?.students || 0}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Teachers</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-32 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ 
                                width: `${(stats.users?.teachers / (stats.users?.total || 1)) * 100}%` 
                              }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {stats.users?.teachers || 0}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Staff</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-32 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-purple-600 h-2 rounded-full" 
                              style={{ 
                                width: `${(stats.users?.staff / (stats.users?.total || 1)) * 100}%` 
                              }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {stats.users?.staff || 0}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Class Statistics */}
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Class Statistics</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Total Classes</p>
                        <p className="text-xl font-bold text-gray-900 mt-1">
                          {stats.academic?.classes || 0}
                        </p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Total Subjects</p>
                        <p className="text-xl font-bold text-gray-900 mt-1">
                          {stats.academic?.subjects || 0}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Enrollment Statistics */}
                  {stats.enrollmentStats && stats.enrollmentStats.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Enrollment by Class</h4>
                      <div className="space-y-2">
                        {stats.enrollmentStats.slice(0, 5).map((item, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">{item.class_name}</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-24 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-blue-600 h-2 rounded-full" 
                                  style={{ 
                                    width: `${(item.student_count / 50) * 100}%` // Assuming max 50 per class
                                  }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium text-gray-900">
                                {item.student_count}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            )}
          </Card>

          {/* Recent Activities Report */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Activities</CardTitle>
                <button
                  onClick={() => toggleSection('activities')}
                  className="text-gray-500 hover:text-gray-700"
                >
                  {expandedSection === 'activities' ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>
              </div>
            </CardHeader>
            {expandedSection === 'activities' && (
              <>
                <CardContent>
                  {auditLogsLoading ? (
                    <div className="py-8 text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    </div>
                  ) : auditLogs.length === 0 ? (
                    <div className="text-center py-8">
                      <Clock className="h-12 w-12 text-gray-400 mx-auto" />
                      <p className="text-gray-600 mt-2">No recent activities</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {auditLogs.slice(0, 10).map((log, index) => (
                        <div key={index} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg">
                          <div className="bg-blue-100 p-2 rounded-full">
                            <Clock className="h-4 w-4 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm text-gray-900">
                              <span className="font-medium">{log.user_name || 'System'}</span>{' '}
                              {log.action?.replace(/_/g, ' ').toLowerCase()}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {new Date(log.created_at).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => handleGenerateReport('audit_logs')}
                  >
                    Generate Full Activity Report
                  </Button>
                </CardFooter>
              </>
            )}
          </Card>
        </div>

        {/* Right Column - Filters & Generated Reports */}
        <div className="space-y-6">
          {/* Report Filters */}
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <Filter className="h-5 w-5 text-gray-500 mr-2" />
                  Report Filters
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Report Type
                  </label>
                  <select
                    value={reportFilters.report_type}
                    onChange={(e) => handleFilterChange('report_type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="system_stats">System Statistics</option>
                    <option value="student_performance">Student Performance</option>
                    <option value="attendance">Attendance Report</option>
                    <option value="financial">Financial Report</option>
                    <option value="class_report">Class Report</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date Range
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      value={reportFilters.start_date}
                      onChange={(e) => handleFilterChange('start_date', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Start Date"
                    />
                    <input
                      type="date"
                      value={reportFilters.end_date}
                      onChange={(e) => handleFilterChange('end_date', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="End Date"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Export Format
                  </label>
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="small"
                      className="flex-1"
                      onClick={() => handleGenerateReport('pdf')}
                    >
                      PDF
                    </Button>
                    <Button 
                      variant="outline" 
                      size="small"
                      className="flex-1"
                      onClick={() => handleGenerateReport('excel')}
                    >
                      Excel
                    </Button>
                    <Button 
                      variant="outline" 
                      size="small"
                      className="flex-1"
                      onClick={() => handleGenerateReport('csv')}
                    >
                      CSV
                    </Button>
                  </div>
                </div>

                <Button 
                  className="w-full"
                  onClick={() => handleGenerateReport(reportFilters.report_type)}
                >
                  Apply Filters & Generate
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Generated Reports */}
          <Card>
            <CardHeader>
              <CardTitle>Generated Reports</CardTitle>
            </CardHeader>
            <CardContent>
              {generatedReportsLoading ? (
                <div className="py-8 text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                </div>
              ) : generatedReports.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto" />
                  <p className="text-gray-600 mt-2">No reports generated yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {generatedReports.slice(0, 5).map((report) => (
                    <div key={report.id} className="border border-gray-200 rounded-lg p-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900 text-sm">
                            {report.report_type.replace('_', ' ')}
                          </h4>
                          <p className="text-xs text-gray-600 mt-1">
                            {new Date(report.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => handleDownloadReport(report)}
                            className="text-blue-600 hover:text-blue-900 p-1"
                            title="Download"
                          >
                            <Download className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-gray-500">
                        Generated by: {report.first_name} {report.last_name}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            {generatedReports.length > 5 && (
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View All Reports ({generatedReports.length})
                </Button>
              </CardFooter>
            )}
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => handleGenerateReport('daily_summary')}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Daily Summary
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => handleGenerateReport('weekly_report')}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Weekly Report
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => handleGenerateReport('monthly_analysis')}
                >
                  <PieChart className="h-4 w-4 mr-2" />
                  Monthly Analysis
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Reports;