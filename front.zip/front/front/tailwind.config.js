/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  experimental: {
    // In v4, dark mode is enabled by default with class strategy
  }
}