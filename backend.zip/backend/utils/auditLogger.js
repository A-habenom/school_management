const { pool } = require('../config/database');

const createAuditLog = async (userId, action, tableName = null, recordId = null, oldValues = null, newValues = null, req = null) => {
    try {
        await pool.query(
            `INSERT INTO audit_logs (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                userId, 
                action, 
                tableName, 
                recordId,
                oldValues ? JSON.stringify(oldValues) : null,
                newValues ? JSON.stringify(newValues) : null,
                req?.ip || req?.connection?.remoteAddress,
                req?.get('user-agent')
            ]
        );
    } catch (error) {
        console.error('Failed to create audit log:', error);
    }
};

module.exports = { createAuditLog };