const { pool } = require('../config/database');

// Helper function for database queries
const query = async (sql, params = []) => {
    try {
        const [results] = await pool.query(sql, params);
        return results;
    } catch (error) {
        console.error('Database query error:', error);
        throw error;
    }
};

// Helper function for single row queries
const queryOne = async (sql, params = []) => {
    const results = await query(sql, params);
    return results[0] || null;
};

// Helper for inserting data and returning ID
const insert = async (table, data) => {
    const keys = Object.keys(data);
    const values = Object.values(data);
    const placeholders = keys.map(() => '?').join(', ');
    
    const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${placeholders})`;
    const [result] = await pool.query(sql, values);
    
    return result.insertId;
};

module.exports = { query, queryOne, insert };