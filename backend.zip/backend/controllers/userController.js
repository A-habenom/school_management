const bcrypt = require('bcryptjs');
const { pool } = require('../config/database');
const { createAuditLog } = require('../utils/auditLogger');

// @desc    Get all users
// @route   GET /api/users
// @access  Private/Admin
const getUsers = async (req, res) => {
    try {
        const { role, user_type, is_active, page = 1, limit = 10 } = req.query;
        
        let query = `
            SELECT id, username, email, first_name, last_name, role, user_type, 
                   date_of_birth, phone, address, is_active, created_at 
            FROM users 
            WHERE 1=1
        `;
        
        let countQuery = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
        const params = [];
        const countParams = [];

        // Apply filters
        if (role) {
            query += ' AND role = ?';
            countQuery += ' AND role = ?';
            params.push(role);
            countParams.push(role);
        }
        
        if (user_type) {
            query += ' AND user_type = ?';
            countQuery += ' AND user_type = ?';
            params.push(user_type);
            countParams.push(user_type);
        }
        
        if (is_active !== undefined) {
            query += ' AND is_active = ?';
            countQuery += ' AND is_active = ?';
            params.push(is_active === 'true');
            countParams.push(is_active === 'true');
        }

        // Add pagination
        const offset = (page - 1) * limit;
        query += ' LIMIT ? OFFSET ?';
        params.push(parseInt(limit), offset);

        // Execute queries
        const [users] = await pool.query(query, params);
        const [[{ total }]] = await pool.query(countQuery, countParams);

        res.json({
            success: true,
            data: users,
            pagination: {
                total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// @desc    Get single user
// @route   GET /api/users/:id
// @access  Private
const getUserById = async (req, res) => {
    try {
        const { id } = req.params;
        
        const [users] = await pool.query(
            `SELECT id, username, email, first_name, last_name, role, user_type, 
                    date_of_birth, phone, address, is_active, created_at 
             FROM users WHERE id = ?`,
            [id]
        );

        if (users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        res.json({
            success: true,
            data: users[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// @desc    Create user
// @route   POST /api/users
// @access  Private/Admin
const createUser = async (req, res) => {
    try {
        const { username, email, password, first_name, last_name, role, user_type, date_of_birth, phone, address } = req.body;

        // Check if user exists
        const [existingUser] = await pool.query(
            'SELECT id FROM users WHERE email = ? OR username = ?',
            [email, username]
        );

        if (existingUser.length > 0) {
            return res.status(400).json({ success: false, message: 'Username or email already exists' });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const [result] = await pool.query(
            `INSERT INTO users (username, email, password, first_name, last_name, role, user_type, date_of_birth, phone, address) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [username, email, hashedPassword, first_name, last_name, role, user_type, date_of_birth, phone, address]
        );

        const [newUser] = await pool.query(
            'SELECT id, username, email, first_name, last_name, role, user_type, is_active, created_at FROM users WHERE id = ?',
            [result.insertId]
        );

        // Create audit log
        await createAuditLog(req.user.id, 'USER_CREATE', 'users', result.insertId, null, newUser[0], req);

        res.status(201).json({
            success: true,
            data: newUser[0],
            message: 'User created successfully'
        });
    } catch (error) {
        console.error(error);
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ success: false, message: 'Username or email already exists' });
        }
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// @desc    Update user
// @route   PUT /api/users/:id
// @access  Private/Admin
const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        // Get old user data for audit log
        const [oldUsers] = await pool.query(
            'SELECT * FROM users WHERE id = ?',
            [id]
        );

        if (oldUsers.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const oldUser = oldUsers[0];

        // Build dynamic update query
        const updateFields = [];
        const values = [];

        Object.keys(updates).forEach(key => {
            if (key !== 'id' && key !== 'password' && key !== 'created_at') {
                updateFields.push(`${key} = ?`);
                values.push(updates[key]);
            }
        });

        if (updateFields.length === 0) {
            return res.status(400).json({ success: false, message: 'No fields to update' });
        }

        values.push(id);
        const query = `UPDATE users SET ${updateFields.join(', ')} WHERE id = ?`;

        await pool.query(query, values);

        // Get updated user
        const [updatedUsers] = await pool.query(
            'SELECT * FROM users WHERE id = ?',
            [id]
        );

        // Create audit log
        await createAuditLog(req.user.id, 'USER_UPDATE', 'users', id, oldUser, updatedUsers[0], req);

        res.json({
            success: true,
            data: updatedUsers[0],
            message: 'User updated successfully'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// @desc    Deactivate user
// @route   PUT /api/users/:id/deactivate
// @access  Private/Admin
const deactivateUser = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if user exists
        const [users] = await pool.query(
            'SELECT * FROM users WHERE id = ?',
            [id]
        );

        if (users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        await pool.query(
            'UPDATE users SET is_active = false WHERE id = ?',
            [id]
        );

        // Create audit log
        await createAuditLog(req.user.id, 'USER_DEACTIVATE', 'users', id, users[0], { ...users[0], is_active: false }, req);

        res.json({
            success: true,
            message: 'User deactivated successfully'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// @desc    Activate user
// @route   PUT /api/users/:id/activate
// @access  Private/Admin
const activateUser = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if user exists
        const [users] = await pool.query(
            'SELECT * FROM users WHERE id = ?',
            [id]
        );

        if (users.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        await pool.query(
            'UPDATE users SET is_active = true WHERE id = ?',
            [id]
        );

        // Create audit log
        await createAuditLog(req.user.id, 'USER_ACTIVATE', 'users', id, users[0], { ...users[0], is_active: true }, req);

        res.json({
            success: true,
            message: 'User activated successfully'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

module.exports = {
    getUsers,
    getUserById,
    createUser,
    updateUser,
    deactivateUser,
    activateUser
};