const { pool } = require('../config/database');
const { createAuditLog } = require('../utils/auditLogger');

// System-wide statistics
const getSystemStats = async (req, res) => {
    try {
        // Get counts using Promise.all for efficiency
        const [
            [totalStudents],
            [totalTeachers],
            [totalStaff],
            [totalClasses],
            [totalSubjects],
            [activeAcademicYear]
        ] = await Promise.all([
            pool.query('SELECT COUNT(*) as count FROM users WHERE user_type = "student" AND is_active = true'),
            pool.query('SELECT COUNT(*) as count FROM users WHERE user_type = "teacher" AND is_active = true'),
            pool.query('SELECT COUNT(*) as count FROM users WHERE user_type = "staff" AND is_active = true'),
            pool.query('SELECT COUNT(*) as count FROM classes'),
            pool.query('SELECT COUNT(*) as count FROM subjects'),
            pool.query('SELECT * FROM academic_years WHERE is_current = true LIMIT 1')
        ]);

        // Get recent audit logs
        const [recentLogs] = await pool.query(`
            SELECT al.*, u.username, u.first_name, u.last_name
            FROM audit_logs al
            LEFT JOIN users u ON al.user_id = u.id
            ORDER BY al.created_at DESC
            LIMIT 10
        `);

        // Get enrollment statistics by class
        const [enrollmentStats] = await pool.query(`
            SELECT c.name as class_name, COUNT(se.id) as student_count
            FROM classes c
            LEFT JOIN student_enrollment se ON c.id = se.class_id AND se.status = 'active'
            GROUP BY c.id
            ORDER BY c.name
        `);

        // Get teacher workload
        const [teacherWorkload] = await pool.query(`
            SELECT u.id, u.first_name, u.last_name, 
                   COUNT(DISTINCT cs.class_id) as classes_count,
                   COUNT(DISTINCT cs.subject_id) as subjects_count,
                   COUNT(t.id) as timetable_slots
            FROM users u
            LEFT JOIN class_subjects cs ON u.id = cs.teacher_id
            LEFT JOIN timetable t ON u.id = t.teacher_id
            WHERE u.user_type = 'teacher' AND u.is_active = true
            GROUP BY u.id
            ORDER BY u.last_name, u.first_name
        `);

        const stats = {
            users: {
                students: totalStudents[0].count,
                teachers: totalTeachers[0].count,
                staff: totalStaff[0].count,
                total: totalStudents[0].count + totalTeachers[0].count + totalStaff[0].count
            },
            academic: {
                classes: totalClasses[0].count,
                subjects: totalSubjects[0].count,
                currentAcademicYear: activeAcademicYear[0] || null
            },
            enrollmentStats,
            teacherWorkload,
            recentActivities: recentLogs
        };

        // Save report to database
        await pool.query(
            'INSERT INTO system_reports (report_type, period, data, generated_by) VALUES (?, ?, ?, ?)',
            ['system_stats', 'current', JSON.stringify(stats), req.user.id]
        );

        res.json({ success: true, data: stats });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Get audit logs
const getAuditLogs = async (req, res) => {
    try {
        const { user_id, action, start_date, end_date, page = 1, limit = 20 } = req.query;

        let query = `
            SELECT al.*, u.username, u.first_name, u.last_name, u.role
            FROM audit_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE 1=1
        `;

        let countQuery = `
            SELECT COUNT(*) as total
            FROM audit_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE 1=1
        `;

        const params = [];
        const countParams = [];

        if (user_id) {
            query += ' AND al.user_id = ?';
            countQuery += ' AND al.user_id = ?';
            params.push(user_id);
            countParams.push(user_id);
        }

        if (action) {
            query += ' AND al.action LIKE ?';
            countQuery += ' AND al.action LIKE ?';
            params.push(`%${action}%`);
            countParams.push(`%${action}%`);
        }

        if (start_date) {
            query += ' AND DATE(al.created_at) >= ?';
            countQuery += ' AND DATE(al.created_at) >= ?';
            params.push(start_date);
            countParams.push(start_date);
        }

        if (end_date) {
            query += ' AND DATE(al.created_at) <= ?';
            countQuery += ' AND DATE(al.created_at) <= ?';
            params.push(end_date);
            countParams.push(end_date);
        }

        query += ' ORDER BY al.created_at DESC';

        // Add pagination
        const offset = (page - 1) * limit;
        query += ' LIMIT ? OFFSET ?';
        params.push(parseInt(limit), offset);

        // Execute queries
        const [logs] = await pool.query(query, params);
        const [[{ total }]] = await pool.query(countQuery, countParams);

        res.json({
            success: true,
            data: logs,
            pagination: {
                total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Generate class report
const generateClassReport = async (req, res) => {
    try {
        const { class_id, academic_year_id } = req.query;

        if (!class_id || !academic_year_id) {
            return res.status(400).json({ success: false, message: 'Class ID and Academic Year ID are required' });
        }

        // Get class details
        const [classInfo] = await pool.query(`
            SELECT c.*, ay.name as academic_year_name,
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM classes c
            LEFT JOIN academic_years ay ON c.academic_year_id = ay.id
            LEFT JOIN users u ON c.class_teacher_id = u.id
            WHERE c.id = ?
        `, [class_id]);

        if (classInfo.length === 0) {
            return res.status(404).json({ success: false, message: 'Class not found' });
        }

        // Get students in class
        const [students] = await pool.query(`
            SELECT se.*, u.first_name, u.last_name, u.email, u.phone, u.date_of_birth
            FROM student_enrollment se
            JOIN users u ON se.student_id = u.id
            WHERE se.class_id = ? AND se.academic_year_id = ? AND se.status = 'active'
            ORDER BY se.roll_number
        `, [class_id, academic_year_id]);

        // Get subjects allocated to class
        const [subjects] = await pool.query(`
            SELECT cs.*, s.name as subject_name, s.code,
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM class_subjects cs
            JOIN subjects s ON cs.subject_id = s.id
            JOIN users u ON cs.teacher_id = u.id
            WHERE cs.class_id = ? AND cs.academic_year_id = ?
        `, [class_id, academic_year_id]);

        // Get timetable
        const [timetable] = await pool.query(`
            SELECT t.*, s.name as subject_name,
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM timetable t
            JOIN subjects s ON t.subject_id = s.id
            JOIN users u ON t.teacher_id = u.id
            WHERE t.class_id = ? AND t.academic_year_id = ?
            ORDER BY FIELD(t.day_of_week, "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), t.start_time
        `, [class_id, academic_year_id]);

        const report = {
            class: classInfo[0],
            statistics: {
                totalStudents: students.length,
                totalSubjects: subjects.length,
                maleStudents: students.filter(s => s.gender === 'male').length,
                femaleStudents: students.filter(s => s.gender === 'female').length
            },
            students,
            subjects,
            timetable: timetable.reduce((acc, item) => {
                if (!acc[item.day_of_week]) {
                    acc[item.day_of_week] = [];
                }
                acc[item.day_of_week].push(item);
                return acc;
            }, {})
        };

        // Save report
        await pool.query(
            'INSERT INTO system_reports (report_type, period, data, generated_by) VALUES (?, ?, ?, ?)',
            ['class_report', `${class_id}_${academic_year_id}`, JSON.stringify(report), req.user.id]
        );

        await createAuditLog(req.user.id, 'REPORT_GENERATE', 'system_reports', null, null, { report_type: 'class_report' }, req);

        res.json({ success: true, data: report });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Get generated reports
const getReports = async (req, res) => {
    try {
        const { report_type, generated_by, start_date, end_date } = req.query;

        let query = `
            SELECT sr.*, u.username, u.first_name, u.last_name
            FROM system_reports sr
            LEFT JOIN users u ON sr.generated_by = u.id
            WHERE 1=1
        `;

        const params = [];

        if (report_type) {
            query += ' AND sr.report_type = ?';
            params.push(report_type);
        }

        if (generated_by) {
            query += ' AND sr.generated_by = ?';
            params.push(generated_by);
        }

        if (start_date) {
            query += ' AND DATE(sr.created_at) >= ?';
            params.push(start_date);
        }

        if (end_date) {
            query += ' AND DATE(sr.created_at) <= ?';
            params.push(end_date);
        }

        query += ' ORDER BY sr.created_at DESC LIMIT 50';

        const [reports] = await pool.query(query, params);

        res.json({ success: true, data: reports });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

module.exports = {
    getSystemStats,
    getAuditLogs,
    generateClassReport,
    getReports
};