const { pool } = require('../config/database');
const { createAuditLog } = require('../utils/auditLogger');

// Get timetable for class
const getTimetable = async (req, res) => {
    try {
        const { class_id, teacher_id, academic_year_id } = req.query;

        let query = `
            SELECT t.*, c.name as class_name, s.name as subject_name, s.code as subject_code,
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM timetable t
            JOIN classes c ON t.class_id = c.id
            JOIN subjects s ON t.subject_id = s.id
            JOIN users u ON t.teacher_id = u.id
            WHERE 1=1
        `;

        const params = [];

        if (class_id) {
            query += ' AND t.class_id = ?';
            params.push(class_id);
        }

        if (teacher_id) {
            query += ' AND t.teacher_id = ?';
            params.push(teacher_id);
        }

        if (academic_year_id) {
            query += ' AND t.academic_year_id = ?';
            params.push(academic_year_id);
        }

        query += ' ORDER BY FIELD(t.day_of_week, "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), t.start_time';

        const [timetable] = await pool.query(query, params);
        
        // Group by day for better organization
        const groupedTimetable = timetable.reduce((acc, item) => {
            if (!acc[item.day_of_week]) {
                acc[item.day_of_week] = [];
            }
            acc[item.day_of_week].push(item);
            return acc;
        }, {});

        res.json({ success: true, data: groupedTimetable, raw: timetable });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Create timetable entry
const createTimetableEntry = async (req, res) => {
    try {
        const { class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number, academic_year_id } = req.body;

        // Check for time conflicts for the same class
        const [conflicts] = await pool.query(`
            SELECT id FROM timetable 
            WHERE class_id = ? 
            AND day_of_week = ?
            AND academic_year_id = ?
            AND (
                (start_time <= ? AND end_time > ?) OR
                (start_time < ? AND end_time >= ?) OR
                (start_time >= ? AND end_time <= ?)
            )
        `, [class_id, day_of_week, academic_year_id, start_time, start_time, end_time, end_time, start_time, end_time]);

        if (conflicts.length > 0) {
            return res.status(400).json({ success: false, message: 'Time slot conflicts with existing schedule' });
        }

        // Check teacher availability
        const [teacherConflicts] = await pool.query(`
            SELECT id FROM timetable 
            WHERE teacher_id = ? 
            AND day_of_week = ?
            AND academic_year_id = ?
            AND (
                (start_time <= ? AND end_time > ?) OR
                (start_time < ? AND end_time >= ?) OR
                (start_time >= ? AND end_time <= ?)
            )
        `, [teacher_id, day_of_week, academic_year_id, start_time, start_time, end_time, end_time, start_time, end_time]);

        if (teacherConflicts.length > 0) {
            return res.status(400).json({ success: false, message: 'Teacher is already assigned during this time' });
        }

        const [result] = await pool.query(
            `INSERT INTO timetable (class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number, academic_year_id) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number, academic_year_id]
        );

        const [newEntry] = await pool.query(`
            SELECT t.*, c.name as class_name, s.name as subject_name,
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM timetable t
            JOIN classes c ON t.class_id = c.id
            JOIN subjects s ON t.subject_id = s.id
            JOIN users u ON t.teacher_id = u.id
            WHERE t.id = ?
        `, [result.insertId]);

        await createAuditLog(req.user.id, 'TIMETABLE_CREATE', 'timetable', result.insertId, null, newEntry[0], req);

        res.status(201).json({ success: true, data: newEntry[0], message: 'Timetable entry created' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Update timetable entry
const updateTimetableEntry = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;

        // Get old entry
        const [oldEntries] = await pool.query('SELECT * FROM timetable WHERE id = ?', [id]);
        if (oldEntries.length === 0) {
            return res.status(404).json({ success: false, message: 'Timetable entry not found' });
        }

        const oldEntry = oldEntries[0];

        // Build update query
        const updateFields = [];
        const values = [];

        Object.keys(updates).forEach(key => {
            if (key !== 'id' && key !== 'created_at') {
                updateFields.push(`${key} = ?`);
                values.push(updates[key]);
            }
        });

        if (updateFields.length === 0) {
            return res.status(400).json({ success: false, message: 'No fields to update' });
        }

        values.push(id);
        const query = `UPDATE timetable SET ${updateFields.join(', ')} WHERE id = ?`;

        await pool.query(query, values);

        const [updatedEntry] = await pool.query('SELECT * FROM timetable WHERE id = ?', [id]);

        await createAuditLog(req.user.id, 'TIMETABLE_UPDATE', 'timetable', id, oldEntry, updatedEntry[0], req);

        res.json({ success: true, data: updatedEntry[0], message: 'Timetable entry updated' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Delete timetable entry
const deleteTimetableEntry = async (req, res) => {
    try {
        const { id } = req.params;

        const [entry] = await pool.query('SELECT * FROM timetable WHERE id = ?', [id]);
        if (entry.length === 0) {
            return res.status(404).json({ success: false, message: 'Timetable entry not found' });
        }

        await pool.query('DELETE FROM timetable WHERE id = ?', [id]);

        await createAuditLog(req.user.id, 'TIMETABLE_DELETE', 'timetable', id, entry[0], null, req);

        res.json({ success: true, message: 'Timetable entry deleted' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Get personal timetable (for teachers/students)
const getPersonalTimetable = async (req, res) => {
    try {
        const userId = req.user.id;
        const userRole = req.user.role;
        const { academic_year_id } = req.query;

        let timetable;

        if (userRole === 'teacher') {
            // Get teacher's timetable
            const query = `
                SELECT t.*, c.name as class_name, s.name as subject_name, s.code as subject_code
                FROM timetable t
                JOIN classes c ON t.class_id = c.id
                JOIN subjects s ON t.subject_id = s.id
                WHERE t.teacher_id = ?
                ${academic_year_id ? 'AND t.academic_year_id = ?' : ''}
                ORDER BY FIELD(t.day_of_week, "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), t.start_time
            `;

            const params = academic_year_id ? [userId, academic_year_id] : [userId];
            [timetable] = await pool.query(query, params);

        } else if (userRole === 'student') {
            // Get student's class timetable
            const [enrollment] = await pool.query(
                `SELECT class_id FROM student_enrollment 
                 WHERE student_id = ? 
                 AND status = 'active'
                 ${academic_year_id ? 'AND academic_year_id = ?' : 'ORDER BY academic_year_id DESC LIMIT 1'}`,
                academic_year_id ? [userId, academic_year_id] : [userId]
            );

            if (enrollment.length === 0) {
                return res.json({ success: true, data: [], message: 'No active enrollment found' });
            }

            const classId = enrollment[0].class_id;
            [timetable] = await pool.query(`
                SELECT t.*, c.name as class_name, s.name as subject_name, s.code as subject_code,
                       u.first_name as teacher_first_name, u.last_name as teacher_last_name
                FROM timetable t
                JOIN classes c ON t.class_id = c.id
                JOIN subjects s ON t.subject_id = s.id
                JOIN users u ON t.teacher_id = u.id
                WHERE t.class_id = ?
                ${academic_year_id ? 'AND t.academic_year_id = ?' : ''}
                ORDER BY FIELD(t.day_of_week, "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"), t.start_time
            `, academic_year_id ? [classId, academic_year_id] : [classId]);
        } else {
            return res.status(403).json({ success: false, message: 'Access denied' });
        }

        // Group by day
        const groupedTimetable = timetable.reduce((acc, item) => {
            if (!acc[item.day_of_week]) {
                acc[item.day_of_week] = [];
            }
            acc[item.day_of_week].push(item);
            return acc;
        }, {});

        res.json({ success: true, data: groupedTimetable, raw: timetable });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

module.exports = {
    getTimetable,
    createTimetableEntry,
    updateTimetableEntry,
    deleteTimetableEntry,
    getPersonalTimetable
};