const { pool } = require('../config/database');
const { createAuditLog } = require('../utils/auditLogger');

// Academic Years
const getAcademicYears = async (req, res) => {
    try {
        const [years] = await pool.query('SELECT * FROM academic_years ORDER BY start_date DESC');
        res.json({ success: true, data: years });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const createAcademicYear = async (req, res) => {
    try {
        const { name, start_date, end_date, is_current } = req.body;

        // If setting as current, deactivate all other current years
        if (is_current) {
            await pool.query('UPDATE academic_years SET is_current = false');
        }

        const [result] = await pool.query(
            'INSERT INTO academic_years (name, start_date, end_date, is_current) VALUES (?, ?, ?, ?)',
            [name, start_date, end_date, is_current || false]
        );

        const [newYear] = await pool.query('SELECT * FROM academic_years WHERE id = ?', [result.insertId]);

        await createAuditLog(req.user.id, 'ACADEMIC_YEAR_CREATE', 'academic_years', result.insertId, null, newYear[0], req);

        res.status(201).json({ success: true, data: newYear[0], message: 'Academic year created' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const setCurrentAcademicYear = async (req, res) => {
    try {
        const { id } = req.params;

        // Deactivate all other current years
        await pool.query('UPDATE academic_years SET is_current = false');
        
        // Set selected year as current
        await pool.query('UPDATE academic_years SET is_current = true WHERE id = ?', [id]);

        const [year] = await pool.query('SELECT * FROM academic_years WHERE id = ?', [id]);

        await createAuditLog(req.user.id, 'ACADEMIC_YEAR_SET_CURRENT', 'academic_years', id, null, year[0], req);

        res.json({ success: true, data: year[0], message: 'Academic year set as current' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Subjects
const getSubjects = async (req, res) => {
    try {
        const [subjects] = await pool.query('SELECT * FROM subjects ORDER BY name');
        res.json({ success: true, data: subjects });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const createSubject = async (req, res) => {
    try {
        const { name, code, description } = req.body;

        const [result] = await pool.query(
            'INSERT INTO subjects (name, code, description) VALUES (?, ?, ?)',
            [name, code, description]
        );

        const [newSubject] = await pool.query('SELECT * FROM subjects WHERE id = ?', [result.insertId]);

        await createAuditLog(req.user.id, 'SUBJECT_CREATE', 'subjects', result.insertId, null, newSubject[0], req);

        res.status(201).json({ success: true, data: newSubject[0], message: 'Subject created' });
    } catch (error) {
        console.error(error);
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ success: false, message: 'Subject code already exists' });
        }
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const updateSubject = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, code, description } = req.body;

        // Get old subject data
        const [oldSubjects] = await pool.query('SELECT * FROM subjects WHERE id = ?', [id]);
        if (oldSubjects.length === 0) {
            return res.status(404).json({ success: false, message: 'Subject not found' });
        }

        await pool.query(
            'UPDATE subjects SET name = ?, code = ?, description = ? WHERE id = ?',
            [name, code, description, id]
        );

        const [updatedSubject] = await pool.query('SELECT * FROM subjects WHERE id = ?', [id]);

        await createAuditLog(req.user.id, 'SUBJECT_UPDATE', 'subjects', id, oldSubjects[0], updatedSubject[0], req);

        res.json({ success: true, data: updatedSubject[0], message: 'Subject updated' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const deleteSubject = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if subject is being used
        const [classSubjects] = await pool.query('SELECT id FROM class_subjects WHERE subject_id = ?', [id]);
        if (classSubjects.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Cannot delete subject that is assigned to classes' 
            });
        }

        const [subject] = await pool.query('SELECT * FROM subjects WHERE id = ?', [id]);
        
        await pool.query('DELETE FROM subjects WHERE id = ?', [id]);

        await createAuditLog(req.user.id, 'SUBJECT_DELETE', 'subjects', id, subject[0], null, req);

        res.json({ success: true, message: 'Subject deleted' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

module.exports = {
    getAcademicYears,
    createAcademicYear,
    setCurrentAcademicYear,
    getSubjects,
    createSubject,
    updateSubject,
    deleteSubject
};