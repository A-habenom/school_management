const { pool } = require('../config/database');
const { createAuditLog } = require('../utils/auditLogger');

// Classes
const getClasses = async (req, res) => {
    try {
        const [classes] = await pool.query(`
            SELECT c.*, ay.name as academic_year_name, 
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM classes c
            LEFT JOIN academic_years ay ON c.academic_year_id = ay.id
            LEFT JOIN users u ON c.class_teacher_id = u.id
            ORDER BY c.name, c.section
        `);
        res.json({ success: true, data: classes });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const createClass = async (req, res) => {
    try {
        const { name, academic_year_id, section, capacity, class_teacher_id } = req.body;

        const [result] = await pool.query(
            'INSERT INTO classes (name, academic_year_id, section, capacity, class_teacher_id) VALUES (?, ?, ?, ?, ?)',
            [name, academic_year_id, section, capacity || 30, class_teacher_id]
        );

        const [newClass] = await pool.query(`
            SELECT c.*, ay.name as academic_year_name 
            FROM classes c
            LEFT JOIN academic_years ay ON c.academic_year_id = ay.id
            WHERE c.id = ?
        `, [result.insertId]);

        await createAuditLog(req.user.id, 'CLASS_CREATE', 'classes', result.insertId, null, newClass[0], req);

        res.status(201).json({ success: true, data: newClass[0], message: 'Class created' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Class Subjects Allocation
const allocateSubjectToClass = async (req, res) => {
    try {
        const { class_id, subject_id, teacher_id, academic_year_id } = req.body;

        // Check if allocation already exists
        const [existing] = await pool.query(
            'SELECT id FROM class_subjects WHERE class_id = ? AND subject_id = ? AND academic_year_id = ?',
            [class_id, subject_id, academic_year_id]
        );

        if (existing.length > 0) {
            return res.status(400).json({ success: false, message: 'Subject already allocated to this class' });
        }

        const [result] = await pool.query(
            'INSERT INTO class_subjects (class_id, subject_id, teacher_id, academic_year_id) VALUES (?, ?, ?, ?)',
            [class_id, subject_id, teacher_id, academic_year_id]
        );

        const [newAllocation] = await pool.query(`
            SELECT cs.*, c.name as class_name, s.name as subject_name, 
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM class_subjects cs
            JOIN classes c ON cs.class_id = c.id
            JOIN subjects s ON cs.subject_id = s.id
            JOIN users u ON cs.teacher_id = u.id
            WHERE cs.id = ?
        `, [result.insertId]);

        await createAuditLog(req.user.id, 'SUBJECT_ALLOCATE', 'class_subjects', result.insertId, null, newAllocation[0], req);

        res.status(201).json({ success: true, data: newAllocation[0], message: 'Subject allocated to class' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const getClassSubjects = async (req, res) => {
    try {
        const { class_id, academic_year_id } = req.query;

        let query = `
            SELECT cs.*, c.name as class_name, s.name as subject_name, s.code as subject_code,
                   u.first_name as teacher_first_name, u.last_name as teacher_last_name
            FROM class_subjects cs
            JOIN classes c ON cs.class_id = c.id
            JOIN subjects s ON cs.subject_id = s.id
            JOIN users u ON cs.teacher_id = u.id
            WHERE 1=1
        `;

        const params = [];

        if (class_id) {
            query += ' AND cs.class_id = ?';
            params.push(class_id);
        }

        if (academic_year_id) {
            query += ' AND cs.academic_year_id = ?';
            params.push(academic_year_id);
        }

        query += ' ORDER BY c.name, s.name';

        const [allocations] = await pool.query(query, params);
        res.json({ success: true, data: allocations });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Student Enrollment
const enrollStudent = async (req, res) => {
    try {
        const { student_id, class_id, academic_year_id, enrollment_date, roll_number } = req.body;

        // Check if student is already enrolled for this academic year
        const [existing] = await pool.query(
            'SELECT id FROM student_enrollment WHERE student_id = ? AND academic_year_id = ?',
            [student_id, academic_year_id]
        );

        if (existing.length > 0) {
            return res.status(400).json({ success: false, message: 'Student already enrolled for this academic year' });
        }

        const [result] = await pool.query(
            'INSERT INTO student_enrollment (student_id, class_id, academic_year_id, enrollment_date, roll_number) VALUES (?, ?, ?, ?, ?)',
            [student_id, class_id, academic_year_id, enrollment_date || new Date(), roll_number]
        );

        const [enrollment] = await pool.query(`
            SELECT se.*, u.first_name as student_first_name, u.last_name as student_last_name,
                   c.name as class_name, ay.name as academic_year_name
            FROM student_enrollment se
            JOIN users u ON se.student_id = u.id
            JOIN classes c ON se.class_id = c.id
            JOIN academic_years ay ON se.academic_year_id = ay.id
            WHERE se.id = ?
        `, [result.insertId]);

        await createAuditLog(req.user.id, 'STUDENT_ENROLL', 'student_enrollment', result.insertId, null, enrollment[0], req);

        res.status(201).json({ success: true, data: enrollment[0], message: 'Student enrolled successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

const getClassStudents = async (req, res) => {
    try {
        const { class_id, academic_year_id, status } = req.query;

        let query = `
            SELECT se.*, u.first_name, u.last_name, u.email, u.phone, 
                   c.name as class_name, ay.name as academic_year_name
            FROM student_enrollment se
            JOIN users u ON se.student_id = u.id
            JOIN classes c ON se.class_id = c.id
            JOIN academic_years ay ON se.academic_year_id = ay.id
            WHERE 1=1
        `;

        const params = [];

        if (class_id) {
            query += ' AND se.class_id = ?';
            params.push(class_id);
        }

        if (academic_year_id) {
            query += ' AND se.academic_year_id = ?';
            params.push(academic_year_id);
        }

        if (status) {
            query += ' AND se.status = ?';
            params.push(status);
        }

        query += ' ORDER BY se.roll_number, u.last_name, u.first_name';

        const [students] = await pool.query(query, params);
        res.json({ success: true, data: students });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

module.exports = {
    getClasses,
    createClass,
    allocateSubjectToClass,
    getClassSubjects,
    enrollStudent,
    getClassStudents
};