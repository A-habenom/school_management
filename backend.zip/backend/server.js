const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const helmet = require('helmet');
const morgan = require('morgan');
const { testConnection } = require('./config/database');
const errorHandler = require('./middleware/errorHandler');

// Import routes ?-------------?
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const academicRoutes = require('./routes/academicRoutes');
const classRoutes = require('./routes/classRoutes');
const timetableRoutes = require('./routes/timetableRoutes');
const reportRoutes = require('./routes/reportRoutes');

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();

// Middleware
app.use(helmet());
app.use(cors({
    origin: '*',
    credentials: true
}));
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging middleware middleare are functions that run during the request processing
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/academic', academicRoutes);
app.use('/api/classes', classRoutes);
app.use('/api/timetable', timetableRoutes);
app.use('/api/reports', reportRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.status(200).json({ 
        status: 'OK', 
        message: 'School Management API is running',
        timestamp: new Date().toISOString()
    });
});

// Database info endpoint
app.get('/api/db-info', async (req, res) => {
    try {
        const { pool } = require('./config/database');
        const [rows] = await pool.query('SELECT VERSION() as version');
        res.json({
            database: 'MySQL',
            version: rows[0].version,
            status: 'Connected'
        });
    } catch (error) {
        res.status(500).json({ error: 'Database connection failed' });
    }
});

// API documentation endpoint
app.get('/api', (req, res) => {
    res.json({
        name: 'School Management System API',
        version: '1.0.0',
        endpoints: {
            auth: {
                register: 'POST /api/auth/register',
                login: 'POST /api/auth/login',
                getMe: 'GET /api/auth/me',
                changePassword: 'PUT /api/auth/change-password'
            },
            users: {
                getAll: 'GET /api/users',
                getById: 'GET /api/users/:id',
                create: 'POST /api/users',
                update: 'PUT /api/users/:id',
                deactivate: 'PUT /api/users/:id/deactivate',
                activate: 'PUT /api/users/:id/activate'
            },
            academic: {
                years: {
                    getAll: 'GET /api/academic/years',
                    create: 'POST /api/academic/years',
                    setCurrent: 'PUT /api/academic/years/:id/set-current'
                },
                subjects: {
                    getAll: 'GET /api/academic/subjects',
                    create: 'POST /api/academic/subjects',
                    update: 'PUT /api/academic/subjects/:id',
                    delete: 'DELETE /api/academic/subjects/:id'
                }
            },
            classes: {
                getAll: 'GET /api/classes',
                create: 'POST /api/classes',
                allocateSubject: 'POST /api/classes/allocate-subject',
                getSubjects: 'GET /api/classes/subjects',
                enrollStudent: 'POST /api/classes/enroll',
                getStudents: 'GET /api/classes/students'
            },
            timetable: {
                getAll: 'GET /api/timetable',
                create: 'POST /api/timetable',
                update: 'PUT /api/timetable/:id',
                delete: 'DELETE /api/timetable/:id',
                personal: 'GET /api/timetable/personal'
            },
            reports: {
                stats: 'GET /api/reports/stats',
                auditLogs: 'GET /api/reports/audit-logs',
                classReport: 'GET /api/reports/class-report',
                generatedReports: 'GET /api/reports/generated'
            }
        }
    });
});

// Error handling middleware
app.use(errorHandler);

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({ 
        success: false, 
        message: `Route ${req.originalUrl} not found` 
    });
});

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        // Test database connection
        await testConnection();
        
        app.listen(PORT, () => {
            console.log(`🚀 Server running on port ${PORT}`);
            console.log(`📚 API Documentation: http://localhost:${PORT}/api`);
            console.log(`🏥 Health check: http://localhost:${PORT}/api/health`);
            console.log(`🗄️  Database info: http://localhost:${PORT}/api/db-info`);
        });
    } catch (error) {
        console.error('❌ Failed to start server:', error);
        process.exit(1);
    }
};

startServer();