const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { 
    getClasses, 
    createClass, 
    allocateSubjectToClass, 
    getClassSubjects, 
    enrollStudent, 
    getClassStudents 
} = require('../controllers/classController');
const { protect, authorize } = require('../middleware/auth');

// All routes protected
router.use(protect);

// Classes
router.get('/', getClasses);
router.post('/', 
    authorize('admin'),
    [
        body('name').notEmpty(),
        body('academic_year_id').isInt()
    ],
    createClass
);

// Class Subjects Allocation
router.post('/allocate-subject',
    authorize('admin'),
    [
        body('class_id').isInt(),
        body('subject_id').isInt(),
        body('teacher_id').isInt(),
        body('academic_year_id').isInt()
    ],
    allocateSubjectToClass
);
router.get('/subjects', getClassSubjects);

// Student Enrollment
router.post('/enroll',
    authorize('admin'),
    [
        body('student_id').isInt(),
        body('class_id').isInt(),
        body('academic_year_id').isInt()
    ],
    enrollStudent
);
router.get('/students', getClassStudents);

module.exports = router;