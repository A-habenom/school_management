const express = require('express');
const router = express.Router();
const { 
    getSystemStats, 
    getAuditLogs, 
    generateClassReport, 
    getReports 
} = require('../controllers/reportController');
const { protect, authorize } = require('../middleware/auth');

// All routes protected
router.use(protect);

// System reports (Admin only)
router.get('/stats', authorize('admin'), getSystemStats);
router.get('/audit-logs', authorize('admin'), getAuditLogs);
router.get('/class-report', authorize('admin', 'teacher'), generateClassReport);
router.get('/generated', authorize('admin', 'teacher'), getReports);

module.exports = router;