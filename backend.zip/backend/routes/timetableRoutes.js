const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { 
    getTimetable, 
    createTimetableEntry, 
    updateTimetableEntry, 
    deleteTimetableEntry,
    getPersonalTimetable 
} = require('../controllers/timetableController');
const { protect, authorize } = require('../middleware/auth');

// All routes protected
router.use(protect);

// General timetable operations (Admin/Teacher)
router.get('/', getTimetable);
router.post('/',
    authorize('admin', 'teacher'),
    [
        body('class_id').isInt(),
        body('subject_id').isInt(),
        body('teacher_id').isInt(),
        body('day_of_week').isIn(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']),
        body('start_time').matches(/^([0-1][0-9]|2[0-3]):([0-5][0-9])$/),
        body('end_time').matches(/^([0-1][0-9]|2[0-3]):([0-5][0-9])$/),
        body('academic_year_id').isInt()
    ],
    createTimetableEntry
);
router.put('/:id',
    authorize('admin', 'teacher'),
    updateTimetableEntry
);
router.delete('/:id',
    authorize('admin'),
    deleteTimetableEntry
);

// Personal timetable (for teachers and students)
router.get('/personal', getPersonalTimetable);

module.exports = router;