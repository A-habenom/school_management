const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { 
    getUsers, 
    getUserById, 
    createUser, 
    updateUser, 
    deactivateUser, 
    activateUser 
} = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

// All routes protected
router.use(protect);

// Admin only routes
router.get('/', authorize('admin'), getUsers);
router.post('/', 
    authorize('admin'),
    [
        body('username').notEmpty(),
        body('email').isEmail(),
        body('password').isLength({ min: 6 }),
        body('first_name').notEmpty(),
        body('last_name').notEmpty(),
        body('role').isIn(['admin', 'teacher', 'student', 'staff']),
        body('user_type').isIn(['student', 'teacher', 'staff'])
    ],
    createUser
);

// Protected routes for all authenticated users
router.get('/:id', getUserById);
router.put('/:id', authorize('admin'), updateUser);
router.put('/:id/deactivate', authorize('admin'), deactivateUser);
router.put('/:id/activate', authorize('admin'), activateUser);

module.exports = router;