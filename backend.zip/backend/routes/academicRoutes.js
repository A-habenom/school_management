const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { 
    getAcademicYears, 
    createAcademicYear, 
    setCurrentAcademicYear,
    getSubjects, 
    createSubject, 
    updateSubject, 
    deleteSubject 
} = require('../controllers/academicController');
const { protect, authorize } = require('../middleware/auth');

// All routes protected
router.use(protect);

// Academic Years
router.get('/years', getAcademicYears);
router.post('/years', 
    authorize('admin'),
    [
        body('name').notEmpty(),
        body('start_date').isDate(),
        body('end_date').isDate()
    ],
    createAcademicYear
);
router.put('/years/:id/set-current', authorize('admin'), setCurrentAcademicYear);

// Subjects
router.get('/subjects', getSubjects);
router.post('/subjects',
    authorize('admin', 'teacher'),
    [
        body('name').notEmpty(),
        body('code').notEmpty()
    ],
    createSubject
);
router.put('/subjects/:id',
    authorize('admin', 'teacher'),
    [
        body('name').notEmpty(),
        body('code').notEmpty()
    ],
    updateSubject
);
router.delete('/subjects/:id', authorize('admin'), deleteSubject);

module.exports = router;